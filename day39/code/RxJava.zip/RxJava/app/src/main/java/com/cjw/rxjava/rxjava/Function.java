package com.cjw.rxjava.rxjava;

public interface Function<T, R> {

    R apply(T t);
}