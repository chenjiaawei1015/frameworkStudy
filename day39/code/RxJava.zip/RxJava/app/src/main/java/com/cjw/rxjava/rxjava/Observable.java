package com.cjw.rxjava.rxjava;

public class Observable<T> {

    private ObservableOnSubscribe<T> mObservableOnSubscribe;

    public Observable(ObservableOnSubscribe<T> observableOnSubscribe) {
        mObservableOnSubscribe = observableOnSubscribe;
    }

    public static <T> Observable<T> create(ObservableOnSubscribe<T> onSubscribe) {
        return new Observable<>(onSubscribe);
    }

    public void subscribe(Emitter<? super T> emitter) {
        mObservableOnSubscribe.onSubscribe(emitter);
    }

    public <R> Observable<R> map(Function<? super T, ? extends R> function) {
        return new Observable<>(new OnSubscribeLift<>(mObservableOnSubscribe, function));
    }
}
