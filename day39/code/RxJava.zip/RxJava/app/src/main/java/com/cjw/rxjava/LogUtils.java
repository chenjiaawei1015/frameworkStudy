package com.cjw.rxjava;

import android.util.Log;

public class LogUtils {

    public static final String TAG = "cjw";

    public static void debug(String msg) {
        Log.d(TAG, msg);
    }

    public static void info(String msg) {
        Log.i(TAG, msg);
    }

}
