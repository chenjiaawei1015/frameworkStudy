package com.cjw.rxjava.rxjava;

public interface ObservableOnSubscribe<T> extends Action<T> {
}
