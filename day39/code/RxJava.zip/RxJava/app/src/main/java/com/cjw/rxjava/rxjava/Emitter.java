package com.cjw.rxjava.rxjava;

public interface Emitter<T> {

    void onNext(T value);

    void onError(Throwable throwable);

    void onComplete();

}
