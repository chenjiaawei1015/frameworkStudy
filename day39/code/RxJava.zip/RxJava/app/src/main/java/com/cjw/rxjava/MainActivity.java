package com.cjw.rxjava;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.cjw.rxjava.rxjava.Emitter;
import com.cjw.rxjava.rxjava.Function;
import com.cjw.rxjava.rxjava.Observable;
import com.cjw.rxjava.rxjava.ObservableOnSubscribe;

/**
 * @author chenjiawei
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void create(View view) {
        Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void onSubscribe(Emitter<? super String> emitter) {
                emitter.onNext("test1");
                emitter.onNext("test2");
            }
        }).subscribe(new Emitter<String>() {
            @Override
            public void onNext(String value) {
                LogUtils.info(value);
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void map(View view) {
        Observable.create(new ObservableOnSubscribe<Integer>() {
            @Override
            public void onSubscribe(Emitter<? super Integer> emitter) {
                emitter.onNext(1);
                emitter.onNext(2);
                emitter.onNext(3);
            }
        }).map(new Function<Integer, String>() {
            @Override
            public String apply(Integer integer) {
                return "data : " + integer;
            }
        }).subscribe(new Emitter<String>() {
            @Override
            public void onNext(String value) {
                LogUtils.info(value);
            }

            @Override
            public void onError(Throwable throwable) {
            }

            @Override
            public void onComplete() {
            }
        });
    }
}
