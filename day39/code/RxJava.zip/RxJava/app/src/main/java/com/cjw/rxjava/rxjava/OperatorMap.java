package com.cjw.rxjava.rxjava;

public class OperatorMap<T, R> implements Operator<T, R> {

    private Function<? super T, ? extends R> mFunction;

    public OperatorMap(Function<? super T, ? extends R> function) {
        mFunction = function;
    }

    @Override
    public Emitter<? super T> apply(Emitter<? super R> emitter) {
        return new EmitterMap(emitter, mFunction);
    }

    private class EmitterMap implements Emitter<T> {

        private Emitter<? super R> mEmitter;
        private Function<? super T, ? extends R> mFunction;

        public EmitterMap(Emitter<? super R> emitter, Function<? super T, ? extends R> function) {
            mEmitter = emitter;
            mFunction = function;
        }

        @Override
        public void onNext(T value) {
            R data = mFunction.apply(value);
            mEmitter.onNext(data);
        }

        @Override
        public void onError(Throwable throwable) {
            mEmitter.onError(throwable);
        }

        @Override
        public void onComplete() {
            mEmitter.onComplete();
        }
    }
}
