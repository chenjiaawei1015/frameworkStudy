package com.cjw.rxjava.rxjava;

/**
 * @author chenjiawei
 */
public class OnSubscribeLift<T, R> implements ObservableOnSubscribe<R> {

    private ObservableOnSubscribe<T> mObservableOnSubscribe;
    private OperatorMap<T, R> mOperatorMap;

    public OnSubscribeLift(ObservableOnSubscribe<T> observableOnSubscribe, Function<? super T, ? extends R> function) {
        mObservableOnSubscribe = observableOnSubscribe;
        mOperatorMap = new OperatorMap<>(function);
    }

    @Override
    public void onSubscribe(Emitter<? super R> emitter) {
        Emitter<? super T> emitter1 = mOperatorMap.apply(emitter);
        mObservableOnSubscribe.onSubscribe(emitter1);
    }
}
