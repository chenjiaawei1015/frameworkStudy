package com.cjw.rxjava.rxjava;

public interface Action<T> {

    void onSubscribe(Emitter<? super T> emitter);
}
