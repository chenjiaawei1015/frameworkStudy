package com.cjw.core.application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Interceptor;

public class Configurator {

    private static final Map<Object, Object> CONFIG_MAP = new HashMap<>();
    private static final List<Interceptor> INTERCEPTOR_MAP = new ArrayList<>();

    private Configurator() {
        CONFIG_MAP.put(ConfigKeys.CONFIG_READY, false);
    }

    public static Map<Object, Object> getConfigs() {
        return CONFIG_MAP;
    }

    public static Object getConfiguration(Object key) {
        return CONFIG_MAP.get(key);
    }

    public static Configurator getInstance() {
        return Holder.INSTANCE;
    }

    /** 配置APIHOST */
    public final Configurator withApiHost(String host) {
        CONFIG_MAP.put(ConfigKeys.API_HOST, host);
        return this;
    }

    /** 设置拦截器 */
    public final Configurator withInterceptors(ArrayList<Interceptor> interceptors) {
        INTERCEPTOR_MAP.addAll(interceptors);
        CONFIG_MAP.put(ConfigKeys.INTERCEPTOR, INTERCEPTOR_MAP);
        return this;
    }

    /** 检查配置是否完成 */
    private void checkConfiguration() {
        final boolean isReady = (boolean) CONFIG_MAP.get(ConfigKeys.CONFIG_READY.name());
        if (!isReady) {
            throw new RuntimeException("Configuration is not ready,call configure()");
        }
    }

    /** 配置完成 */
    public final void configure() {
        CONFIG_MAP.put(ConfigKeys.CONFIG_READY.name(), true);
    }

    private static class Holder {
        private static final Configurator INSTANCE = new Configurator();
    }

}
