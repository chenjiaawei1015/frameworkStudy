package com.cjw.core.application;

/**
 * @author chenjiawei
 */

public enum ConfigKeys {
    /** 主机名 */
    API_HOST,
    /** application 上下文 */
    APPLICATION_CONTEXT,
    /** 拦截器 */
    INTERCEPTOR,
    /** 是否配置完成 */
    CONFIG_READY
}
