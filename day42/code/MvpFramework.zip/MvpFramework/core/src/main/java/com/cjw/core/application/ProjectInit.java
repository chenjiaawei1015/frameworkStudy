package com.cjw.core.application;

import android.content.Context;

public class ProjectInit {

    public static Configurator init(Context context) {
        Context applicationContext = context.getApplicationContext();
        Configurator.getConfigs().put(ConfigKeys.APPLICATION_CONTEXT.name(), applicationContext);
        return Configurator.getInstance();
    }

    public static Configurator getConfigurator() {
        return Configurator.getInstance();
    }

    public static Object getConfiguration(Object key) {
        return Configurator.getConfiguration(key);
    }

    public static Context getApplicationContext() {
        return (Context) getConfiguration(ConfigKeys.APPLICATION_CONTEXT.name());
    }
}
