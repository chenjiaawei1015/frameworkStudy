package com.cjw.mvpframework.application;

import android.app.Application;

import com.cjw.core.application.Configurator;
import com.cjw.core.application.ProjectInit;

import java.util.ArrayList;

/**
 * @author chenjiawei
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Configurator configurator = ProjectInit.init(this);

        configurator.withApiHost("")
                .withInterceptors(new ArrayList<okhttp3.Interceptor>())
                .configure();
    }
}
