package com.cjw.mvp.mvp.model;

import com.cjw.mvp.bean.ListData;

import java.util.List;

/**
 * @author chenjiawei
 */
public interface IListDataModel {

    void loadData(LoadCallBack callBack);

    interface LoadCallBack {
        void showLoadData(List<ListData> dataList);
    }

}
