package com.cjw.mvp.bean;

public class ListData {

    public String text1;
    public String text2;

}
