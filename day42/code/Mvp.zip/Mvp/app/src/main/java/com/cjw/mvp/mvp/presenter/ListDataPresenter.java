package com.cjw.mvp.mvp.presenter;

import com.cjw.mvp.bean.ListData;
import com.cjw.mvp.mvp.model.IListDataModel;
import com.cjw.mvp.mvp.model.ListDataModelImpl;
import com.cjw.mvp.mvp.view.IListDataView;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * @author chenjiawei
 */
public class ListDataPresenter {

    private WeakReference<IListDataView> mViewRef;
    private IListDataModel mDataModel;

    public ListDataPresenter(IListDataView view) {
        mViewRef = new WeakReference<>(view);
        mDataModel = new ListDataModelImpl();
    }

    public void loadData() {
        mDataModel.loadData(new IListDataModel.LoadCallBack() {
            @Override
            public void showLoadData(List<ListData> dataList) {
                IListDataView view = mViewRef.get();
                if (view != null) {
                    view.showListData(dataList);
                }
            }
        });
    }
}
