package com.cjw.mvp.mvp.view;

import com.cjw.mvp.bean.ListData;

import java.util.List;

public interface IListDataView {

    void showListData(List<ListData> dataList);

}
