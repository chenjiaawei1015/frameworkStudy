package com.cjw.mvp.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.cjw.mvp.R;
import com.cjw.mvp.bean.ListData;
import com.cjw.mvp.mvp.presenter.ListDataPresenter;
import com.cjw.mvp.mvp.view.IListDataView;
import com.cjw.mvp.ui.adapter.MainAdapter;

import java.util.List;

/**
 * @author chenjiawei
 */
public class MainActivity extends AppCompatActivity implements IListDataView {

    private RecyclerView mMainRv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mMainRv = findViewById(R.id.main_rv);

        RecyclerView.LayoutManager manager = new LinearLayoutManager(this);
        mMainRv.setLayoutManager(manager);

        RecyclerView.ItemDecoration decoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        mMainRv.addItemDecoration(decoration);

        new ListDataPresenter(this).loadData();
    }

    @Override
    public void showListData(List<ListData> dataList) {
        RecyclerView.Adapter adapter = new MainAdapter(dataList);
        mMainRv.setAdapter(adapter);
    }
}
