package com.cjw.mvp.ui.adapter;

import android.support.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.cjw.mvp.R;
import com.cjw.mvp.bean.ListData;

import java.util.List;

public class MainAdapter extends BaseQuickAdapter<ListData, BaseViewHolder> {

    public MainAdapter(@Nullable List<ListData> data) {
        super(R.layout.item_list_data, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, ListData item) {
        helper.setText(R.id.data1_tv, item.text1)
                .setText(R.id.data2_tv, item.text2);
    }
}
