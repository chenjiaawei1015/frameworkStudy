package com.cjw.mvp.mvp.model;

import com.cjw.mvp.bean.ListData;

import java.util.ArrayList;
import java.util.List;

public class ListDataModelImpl implements IListDataModel {

    @Override
    public void loadData(LoadCallBack callBack) {
        List<ListData> dataList = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            ListData listData = new ListData();
            listData.text1 = String.valueOf(i);
            listData.text2 = "data" + i;
            dataList.add(listData);
        }

        callBack.showLoadData(dataList);
    }
}
