package com.cjw.demo1;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    Button mJumpTestBt = findViewById(R.id.jump_test_bt);
    Button mJumpPluginBt = findViewById(R.id.jump_plugin_bt);

    mJumpTestBt.setOnClickListener(this);
    mJumpPluginBt.setOnClickListener(this);
  }

  @Override
  public void onClick(View v) {
    switch (v.getId()) {
      case R.id.jump_test_bt: {
        Intent intent = new Intent(this, TestActivity.class);
        startActivity(intent);
        break;
      }

      case R.id.jump_plugin_bt: {
        Intent intent = new Intent();
        ComponentName componentName = new ComponentName("com.cjw.plugin", "com.cjw.plugin.MainActivity");
        intent.setComponent(componentName);
        startActivity(intent);
        break;
      }

      default:
        break;
    }
  }
}
