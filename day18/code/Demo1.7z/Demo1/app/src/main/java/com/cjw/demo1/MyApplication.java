package com.cjw.demo1;

import android.app.Application;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Environment;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class MyApplication extends Application {

  private static final String PLUGIN_APK_NAME = "plugin-debug.apk";
  private Resources mPluginResource;
  private AssetManager mAssetManager;

  @Override
  public void onCreate() {
    super.onCreate();
    Logger.addLogAdapter(new AndroidLogAdapter());

    HookUtils hookUtils = new HookUtils();
    hookUtils.hookStartActivity(this);
    hookUtils.hookActivityThreadHandler();
    hookUtils.hookPluginApk(this);

    initResource(this);
  }

  private void initResource(Application application) {
    Logger.d("begin initResource");
    Resources resources = application.getResources();
    File file = new File(Environment.getExternalStorageDirectory(), PLUGIN_APK_NAME);

    try {
      Constructor<?> constructor = AssetManager.class.getDeclaredConstructor();
      constructor.setAccessible(true);
      mAssetManager = (AssetManager) constructor.newInstance();

      Method addAssetPathMethod = AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
      addAssetPathMethod.setAccessible(true);
      addAssetPathMethod.invoke(mAssetManager, file.getAbsolutePath());

      mPluginResource = new Resources(mAssetManager, resources.getDisplayMetrics(), resources.getConfiguration());

      Logger.d("end initResource");
    } catch (Exception e) {
      e.printStackTrace();
      Logger.e("initResource error");
    }
  }

  @Override public AssetManager getAssets() {
    if (mAssetManager != null) {
      return mAssetManager;
    }
    return super.getAssets();
  }

  @Override public Resources getResources() {
    if (mPluginResource != null) {
      return mPluginResource;
    }
    return super.getResources();
  }
}
