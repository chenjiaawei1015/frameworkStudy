package com.cjw.plugin;

import android.app.Activity;
import android.app.Application;
import android.content.res.AssetManager;
import android.content.res.Resources;

public abstract class BaseActivity extends Activity {

  @Override public Resources getResources() {
    Application application = getApplication();
    if (application != null) {
      Resources resources = application.getResources();
      if (resources != null) {
        return resources;
      }
    }
    return super.getResources();
  }

  @Override public AssetManager getAssets() {
    Application application = getApplication();
    if (application != null) {
      AssetManager assets = application.getAssets();
      if (assets != null) {
        return assets;
      }
    }
    return super.getAssets();
  }
}
