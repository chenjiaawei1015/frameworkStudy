package com.cjw.rxjava.bean;

import android.text.TextUtils;

public abstract class Fruit {

    protected String name;

    public abstract String initName();

    public String getName() {
        if (TextUtils.isEmpty(name)) {
            name = initName();
        }
        return name;
    }
}
