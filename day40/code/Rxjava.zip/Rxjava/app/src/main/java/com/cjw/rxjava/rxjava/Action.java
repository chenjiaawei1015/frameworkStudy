package com.cjw.rxjava.rxjava;

public interface Action<T> {

    void subscribe(Emitter<? super T> emitter);
}
