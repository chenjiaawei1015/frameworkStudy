package com.cjw.rxjava.rxjava;

public class ObservableOnSubscribeLift<T, R> implements ObservableOnSubscribe<R> {

    private OperatorMap<T, R> mOperatorMap;
    private ObservableOnSubscribe<T> mOnSubscribe;

    public ObservableOnSubscribeLift(ObservableOnSubscribe<T> onSubscribe, Function<T, R> function) {
        mOnSubscribe = onSubscribe;
        mOperatorMap = new OperatorMap<>(mOnSubscribe, function);
    }

    @Override
    public void subscribe(Emitter<? super R> emitter) {
        Emitter<? super T> emitter1 = mOperatorMap.apply(emitter);
        mOnSubscribe.subscribe(emitter1);
    }
}
