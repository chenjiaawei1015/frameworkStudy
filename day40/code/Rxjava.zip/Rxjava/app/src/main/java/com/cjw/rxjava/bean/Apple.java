package com.cjw.rxjava.bean;

public class Apple extends Fruit {
    @Override
    public String initName() {
        return "苹果";
    }
}
