package com.cjw.rxjava.rxjava;

public class OperatorMap<T, R> implements Operator<T, R> {

    private ObservableOnSubscribe<? super T> mOnSubscribe;
    private Function<T, R> mFunction;

    public OperatorMap(ObservableOnSubscribe<? super T> onSubscribe, Function<T, R> function) {
        mOnSubscribe = onSubscribe;
        mFunction = function;
    }

    @Override
    public Emitter<? super T> apply(Emitter<? super R> emitter) {
        return new ObserverMap(emitter);
    }

    private class ObserverMap implements Observer<T> {

        private Emitter<? super R> mEmitter;

        ObserverMap(Emitter<? super R> emitter) {
            mEmitter = emitter;
        }

        @Override
        public void onNext(T t) {
            R r = mFunction.apply(t);
            mEmitter.onNext(r);
        }

        @Override
        public void onError(Throwable throwable) {
            mEmitter.onError(throwable);
        }

        @Override
        public void onComplete() {
            mEmitter.onComplete();
        }
    }
}
