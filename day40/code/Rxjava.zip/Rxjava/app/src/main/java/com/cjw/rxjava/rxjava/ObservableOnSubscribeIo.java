package com.cjw.rxjava.rxjava;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ObservableOnSubscribeIo<T> implements ObservableOnSubscribe<T> {

    private final ExecutorService mExecutorService;
    private ObservableOnSubscribe<T> mOnSubscribe;

    public ObservableOnSubscribeIo(ObservableOnSubscribe<T> onSubscribe) {
        mOnSubscribe = onSubscribe;
        mExecutorService = Executors.newCachedThreadPool();
    }

    @Override
    public void subscribe(final Emitter<? super T> emitter) {
        mExecutorService.submit(new Runnable() {
            @Override
            public void run() {
                mOnSubscribe.subscribe(emitter);
            }
        });
    }
}
