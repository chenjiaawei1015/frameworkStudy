package com.cjw.rxjava.rxjava;

public interface Observer<T> extends Emitter<T> {
}
