package com.cjw.rxjava.rxjava;

public class Observable<T> {

    private ObservableOnSubscribe<T> mOnSubscribe;

    public Observable(ObservableOnSubscribe<T> onSubscribe) {
        mOnSubscribe = onSubscribe;
    }

    public static <T> Observable<T> create(ObservableOnSubscribe<T> onSubscribe) {
        return new Observable<>(onSubscribe);
    }

    public void subscribe(Emitter<T> emitter) {
        mOnSubscribe.subscribe(emitter);
    }

    public <R> Observable<R> map(Function<T, R> function) {
        // 转换发射器
        ObservableOnSubscribeLift<T, R> lift = new ObservableOnSubscribeLift<>(mOnSubscribe, function);
        return new Observable<>(lift);
    }

    public Observable<T> subscribeOnIo() {
        ObservableOnSubscribeIo<T> onSubscribeIo = new ObservableOnSubscribeIo<>(mOnSubscribe);
        return create(onSubscribeIo);
    }

    public Observable<T> subscribeOnMain() {
        ObservableOnSubscribeMain<T> onSubscribeMain = new ObservableOnSubscribeMain<>(mOnSubscribe);
        return create(onSubscribeMain);
    }
}
