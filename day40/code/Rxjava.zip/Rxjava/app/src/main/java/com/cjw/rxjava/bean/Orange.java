package com.cjw.rxjava.bean;

public class Orange extends Fruit {
    @Override
    public String initName() {
        return "橙子";
    }
}
