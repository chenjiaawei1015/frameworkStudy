package com.cjw.rxjava.bean;

public class RedApple extends Apple {

    @Override
    public String initName() {
        return "红苹果";
    }
}
