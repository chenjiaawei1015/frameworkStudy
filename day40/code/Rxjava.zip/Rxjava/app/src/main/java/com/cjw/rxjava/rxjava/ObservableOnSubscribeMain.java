package com.cjw.rxjava.rxjava;

import android.os.Handler;
import android.os.Looper;

public class ObservableOnSubscribeMain<T> implements ObservableOnSubscribe<T> {

    private Handler mHandler;
    private ObservableOnSubscribe<T> mOnSubscribe;

    public ObservableOnSubscribeMain(ObservableOnSubscribe<T> onSubscribe) {
        mOnSubscribe = onSubscribe;

        Looper mainLooper = Looper.getMainLooper();
        mHandler = new Handler(mainLooper);
    }

    @Override
    public void subscribe(final Emitter<? super T> emitter) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mOnSubscribe.subscribe(emitter);
            }
        });
    }
}
