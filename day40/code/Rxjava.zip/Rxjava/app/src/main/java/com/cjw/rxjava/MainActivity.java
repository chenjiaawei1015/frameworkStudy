package com.cjw.rxjava;

import android.os.Bundle;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.cjw.rxjava.bean.Apple;
import com.cjw.rxjava.bean.Fruit;
import com.cjw.rxjava.bean.Orange;
import com.cjw.rxjava.bean.RedApple;
import com.cjw.rxjava.rxjava.Emitter;
import com.cjw.rxjava.rxjava.Function;
import com.cjw.rxjava.rxjava.Observable;
import com.cjw.rxjava.rxjava.ObservableOnSubscribe;
import com.cjw.rxjava.rxjava.Observer;

public class MainActivity extends AppCompatActivity {

    private Apple mApple;
    private Orange mOrange;
    private RedApple mRedApple;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mApple = new Apple();
        mOrange = new Orange();
        mRedApple = new RedApple();
    }

    public void create(View view) {
        Observable.create(new ObservableOnSubscribe<Fruit>() {
            @Override
            public void subscribe(Emitter<? super Fruit> emitter) {
                emitter.onNext(mApple);
                emitter.onNext(mOrange);
                emitter.onComplete();
            }
        }).subscribe(new Observer<Fruit>() {
            @Override
            public void onNext(Fruit fruit) {
                String name = fruit.getName();
                System.out.println(name);
            }

            @Override
            public void onError(Throwable throwable) {
                throwable.printStackTrace();
            }

            @Override
            public void onComplete() {
                System.out.println("onComplete");
            }
        });
    }

    public void map(View view) {
        Observable.create(new ObservableOnSubscribe<Integer>() {
            @Override
            public void subscribe(Emitter<? super Integer> emitter) {
                emitter.onNext(1);
                emitter.onNext(2);
                emitter.onNext(3);
            }
        }).map(new Function<Integer, String>() {
            @Override
            public String apply(Integer integer) {
                return "data : " + integer;
            }
        }).subscribe(new Observer<String>() {
            @Override
            public void onNext(String s) {
                System.out.println(s);
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    public void switchThread(View view) {
        long id = Looper.getMainLooper().getThread().getId();
        System.out.println("主线程id : " + id);

        Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(Emitter<? super String> emitter) {
                long id = Thread.currentThread().getId();
                System.out.println("test1 : " + id);
                emitter.onNext("test");
            }
        }).subscribeOnIo().map(new Function<String, String>() {
            @Override
            public String apply(String s) {
                long id = Thread.currentThread().getId();
                System.out.println("test2 : " + id);
                return s;
            }
        }).subscribe(new Observer<String>() {
            @Override
            public void onNext(String s) {
                long id = Thread.currentThread().getId();
                System.out.println("test3 : " + id);
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onComplete() {

            }
        });
    }
}
