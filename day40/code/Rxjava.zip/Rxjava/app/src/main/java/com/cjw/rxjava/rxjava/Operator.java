package com.cjw.rxjava.rxjava;

public interface Operator<T, R> extends Function<Emitter<? super R>, Emitter<? super T>> {
}
