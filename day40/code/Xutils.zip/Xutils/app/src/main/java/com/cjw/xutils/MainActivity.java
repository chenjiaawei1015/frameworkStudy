package com.cjw.xutils;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.cjw.xutils.xutils.InjectUtils;
import com.cjw.xutils.xutils.annotations.ContentView;
import com.cjw.xutils.xutils.annotations.OnClick;
import com.cjw.xutils.xutils.annotations.OnLongClick;
import com.cjw.xutils.xutils.annotations.ViewInject;

@ContentView(R.layout.activity_main)
public class MainActivity extends AppCompatActivity {

    @ViewInject(R.id.test1_bt)
    Button mTest1Bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        InjectUtils.inject(this);

        mTest1Bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "111", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @OnLongClick({R.id.test2_bt, R.id.test3_bt})
    public boolean onLongClickForButton(View view) {
        Toast.makeText(MainActivity.this, "长按事件", Toast.LENGTH_SHORT).show();
        return true;
    }

    @OnClick({R.id.test3_bt, R.id.test4_bt})
    public void onClickForButton(View view) {
        Toast.makeText(MainActivity.this, "单击事件", Toast.LENGTH_SHORT).show();

    }
}
