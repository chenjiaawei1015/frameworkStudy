package com.cjw.xutils.xutils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class ListenerInvocationHandler implements InvocationHandler {

    private Object mObject;
    private Method mDestMethod;

    public ListenerInvocationHandler(Object object, Method method) {
        mObject = object;
        mDestMethod = method;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        return mDestMethod.invoke(mObject, args);
    }
}
