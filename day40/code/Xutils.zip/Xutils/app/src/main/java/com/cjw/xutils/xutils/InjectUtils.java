package com.cjw.xutils.xutils;

import android.view.View;

import com.cjw.xutils.xutils.annotations.ContentView;
import com.cjw.xutils.xutils.annotations.EventBase;
import com.cjw.xutils.xutils.annotations.ViewInject;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class InjectUtils {

    public static void inject(Object object) {
        try {
            injectLayout(object);
            injectView(object);
            injectListener(object);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void injectListener(Object object) throws Exception {
        Class<?> objectClass = object.getClass();
        ClassLoader classLoader = objectClass.getClassLoader();
        Method[] declaredMethods = objectClass.getDeclaredMethods();
        for (Method method : declaredMethods) {
            method.setAccessible(true);
            Annotation[] annotationArr = method.getAnnotations();
            if (annotationArr == null) {
                continue;
            }

            for (Annotation annotation : annotationArr) {
                Class<? extends Annotation> annotationType = annotation.annotationType();
                if (annotationType == null) {
                    continue;
                }

                EventBase eventBase = annotationType.getAnnotation(EventBase.class);
                if (eventBase == null) {
                    continue;
                }

                String listenerSetter = eventBase.listenerSetter();
                Class listenerType = eventBase.listenerType();

                Method valueMethod = annotation.getClass().getMethod("value");
                int[] viewIdArr = (int[]) valueMethod.invoke(annotation);

                if (viewIdArr == null) {
                    continue;
                }

                for (int itemViewId : viewIdArr) {
                    View view = findView(object, itemViewId);
                    Method listenerMethod = view.getClass().getMethod(listenerSetter, listenerType);
                    ListenerInvocationHandler invocationHandler = new ListenerInvocationHandler(object, method);
                    Object proxyListener = Proxy.newProxyInstance(classLoader,
                            new Class[]{listenerType}, invocationHandler);
                    listenerMethod.invoke(view, proxyListener);
                }
            }
        }
    }

    private static void injectView(Object object) throws Exception {
        Class<?> objClass = object.getClass();
        Field[] declaredFields = objClass.getDeclaredFields();
        for (Field field : declaredFields) {
            field.setAccessible(true);
            ViewInject annotation = field.getAnnotation(ViewInject.class);
            if (annotation != null) {
                int viewId = annotation.value();
                View view = findView(object, viewId);
                field.set(object, view);
            }
        }
    }

    private static View findView(Object object, int viewId) throws Exception {
        Class<?> objClass = object.getClass();
        Method method = objClass.getMethod("findViewById", int.class);
        return (View) method.invoke(object, viewId);
    }

    private static void injectLayout(Object object) throws Exception {
        Class<?> objClass = object.getClass();
        ContentView contentViewAnnotation = objClass.getAnnotation(ContentView.class);
        if (contentViewAnnotation != null) {
            int layOutId = contentViewAnnotation.value();
            Method method = objClass.getMethod("setContentView", int.class);
            method.invoke(object, layOutId);
        }
    }


}
