package com.cjw.demo1.http.callback;

import com.cjw.demo1.http.ICallback;
import com.google.gson.Gson;
import java.lang.reflect.ParameterizedType;

public abstract class ModelCallback<T> implements ICallback {

  @Override public void onSuccess(String body) {
    Gson gson = new Gson();
    Class<T> dataClazz = getClassFromBody();
    T data = gson.fromJson(body, dataClazz);
    onRequestSuccess(data);
  }

  private Class<T> getClassFromBody() {
    ParameterizedType type = (ParameterizedType) getClass().getGenericSuperclass();
    return (Class<T>) type.getActualTypeArguments()[0];
  }

  @Override public void onFailed(int errorCode, Throwable throwable) {
    onRequestFailed(errorCode, throwable);
  }

  public abstract void onRequestSuccess(T data);

  public abstract void onRequestFailed(int errorCode, Throwable throwable);
}
