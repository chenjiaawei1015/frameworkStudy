package com.cjw.demo1.http;

import java.util.Map;

public interface IHttpRequest {

  void get(String url, Map<String, String> params, ICallback callback);
}
