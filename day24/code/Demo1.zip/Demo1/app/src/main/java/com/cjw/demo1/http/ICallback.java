package com.cjw.demo1.http;

public interface ICallback {

  void onSuccess(String body);

  void onFailed(int errorCode, Throwable throwable);
}
