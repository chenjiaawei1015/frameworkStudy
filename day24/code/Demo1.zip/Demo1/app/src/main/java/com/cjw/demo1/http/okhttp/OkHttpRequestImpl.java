package com.cjw.demo1.http.okhttp;

import android.support.annotation.NonNull;
import android.util.Log;
import com.cjw.demo1.http.ICallback;
import com.cjw.demo1.http.IHttpRequest;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class OkHttpRequestImpl implements IHttpRequest {

  private static final String TAG = "cjw";

  private OkHttpClient mClient = new OkHttpClient();

  @Override public void get(String url, Map<String, String> params, final ICallback callback) {
    Log.i(TAG, "OkHttpRequestImpl get: ");
    StringBuilder builder = new StringBuilder(url);
    if (params != null && !params.isEmpty()) {
      builder.append("?");
      Set<Map.Entry<String, String>> entrySet = params.entrySet();
      for (Map.Entry<String, String> entry : entrySet) {
        String key = entry.getKey();
        String value = entry.getValue();
        builder.append(key).append("=").append(value).append("&");
      }
      builder.deleteCharAt(builder.length() - 1);
    }
    String loadUrl = builder.toString();
    Log.i(TAG, "loadUrl : " + loadUrl);

    Request request = new Request.Builder().url(loadUrl).build();
    mClient.newCall(request).enqueue(new Callback() {
      @Override public void onFailure(@NonNull Call call, @NonNull IOException e) {
        callback.onFailed(-1, e);
      }

      @Override public void onResponse(@NonNull Call call, @NonNull Response response)
          throws IOException {
        ResponseBody body = response.body();
        if (body != null) {
          String data = body.string();
          callback.onSuccess(data);
        }
      }
    });
  }
}
