package com.cjw.demo1.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import com.cjw.demo1.R;
import com.cjw.demo1.http.HttpRequestPresenter;
import com.cjw.demo1.http.asynchttp.AsyncHttpRequestImpl;
import com.cjw.demo1.http.callback.ModelCallback;
import com.cjw.demo1.http.model.Weather;
import com.cjw.demo1.http.okhttp.OkHttpRequestImpl;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

  private static final String TAG = "cjw";

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    // 天气
    // http://restapi.amap.com/v3/weather/weatherInfo?key=ed36091addaa77fc51afa440b5e571cc&city=深圳
  }

  public void async(View view) {
    HttpRequestPresenter request = HttpRequestPresenter.getInstance(new AsyncHttpRequestImpl());
    requestWeather(request);
  }

  public void okhttp(View view) {
    HttpRequestPresenter request = HttpRequestPresenter.getInstance();
    request.setHttpRequest(new OkHttpRequestImpl());
    requestWeather(request);
  }

  private void requestWeather(HttpRequestPresenter request) {
    String url = "http://restapi.amap.com/v3/weather/weatherInfo";
    Map<String, String> paramsMap = new ArrayMap<>();
    paramsMap.put("key", "ed36091addaa77fc51afa440b5e571cc");
    paramsMap.put("city", "深圳");

    request.get(url, paramsMap, new ModelCallback<Weather>() {
      @Override public void onRequestSuccess(Weather data) {
        List<Weather.LivesBean> beanList = data.getLives();
        Weather.LivesBean livesBean = beanList.get(0);
        Log.i(TAG,
            "onRequestSuccess: " + livesBean.getProvince() + " , " + livesBean.getTemperature());
      }

      @Override public void onRequestFailed(int errorCode, Throwable throwable) {
        throwable.printStackTrace();
      }
    });
  }
}
