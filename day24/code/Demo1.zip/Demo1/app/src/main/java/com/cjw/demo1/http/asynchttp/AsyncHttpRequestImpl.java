package com.cjw.demo1.http.asynchttp;

import android.util.Log;
import com.cjw.demo1.http.ICallback;
import com.cjw.demo1.http.IHttpRequest;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import cz.msebera.android.httpclient.Header;
import java.util.Map;
import java.util.Set;

public class AsyncHttpRequestImpl implements IHttpRequest {

  private static final String TAG = "cjw";

  private AsyncHttpClient mClient = new AsyncHttpClient();

  @Override public void get(String url, Map<String, String> params, final ICallback callback) {
    Log.i(TAG, "AsyncHttpRequestImpl get: ");

    StringBuilder builder = new StringBuilder(url);
    if (params != null && !params.isEmpty()) {
      builder.append("?");
      Set<Map.Entry<String, String>> entrySet = params.entrySet();
      for (Map.Entry<String, String> entry : entrySet) {
        String key = entry.getKey();
        String value = entry.getValue();
        builder.append(key).append("=").append(value).append("&");
      }
      builder.deleteCharAt(builder.length() - 1);
    }
    String loadUrl = builder.toString();

    Log.i(TAG, "loadUrl : " + loadUrl);

    mClient.get(loadUrl, null, new AsyncHttpResponseHandler() {
      @Override public void onSuccess(int i, Header[] headers, byte[] bytes) {
        callback.onSuccess(new String(bytes));
      }

      @Override public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
        callback.onFailed(i, throwable);
      }
    });
  }
}
