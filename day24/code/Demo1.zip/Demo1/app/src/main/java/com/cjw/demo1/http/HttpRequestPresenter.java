package com.cjw.demo1.http;

import java.util.Map;

public class HttpRequestPresenter implements IHttpRequest {

  private static volatile HttpRequestPresenter sInstance;
  private IHttpRequest mHttpRequest;

  public static HttpRequestPresenter getInstance(IHttpRequest httpRequest) {
    if (sInstance == null) {
      synchronized (HttpRequestPresenter.class) {
        if (sInstance == null) {
          sInstance = new HttpRequestPresenter();
          sInstance.mHttpRequest = httpRequest;
        }
      }
    }
    return sInstance;
  }

  public static HttpRequestPresenter getInstance() {
    return sInstance;
  }

  public void setHttpRequest(IHttpRequest httpRequest) {
    mHttpRequest = httpRequest;
  }

  @Override public void get(String url, Map<String, String> params, ICallback callback) {
    sInstance.mHttpRequest.get(url, params, callback);
  }
}
