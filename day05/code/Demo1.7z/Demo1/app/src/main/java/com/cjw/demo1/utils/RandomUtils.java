package com.cjw.demo1.utils;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.UUID;

public class RandomUtils {

    public static final String NUMBER_TYPE = "0123456789";
    public static final String ENGLISH_TYPE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    public static final String PUNCTUATION_TYPE = "!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?";

    public static final String COMMON_TYPE = NUMBER_TYPE + ENGLISH_TYPE;
    public static final String ALL_TYPE = COMMON_TYPE + PUNCTUATION_TYPE;

    private static final int DEFAULT_LENGTH = 10;

    private static SecureRandom sRandom = new SecureRandom();

    private RandomUtils() {
    }

    public static String getStringByUuid() {
        return getStringByUuid(DEFAULT_LENGTH);
    }

    public static String getStringByUuid(int length) {
        String str = UUID.randomUUID().toString().replace("-", "");
        if (length > 0) {
            if (length <= str.length()) {
                return str.substring(0, length);
            } else {
                int lessLength = length - str.length();
                return str + getStringByUuid(lessLength);
            }
        } else {
            return str;
        }
    }

    public static String getString() {
        return getString(COMMON_TYPE);
    }

    private static String getString(String characterType) {
        return getString(characterType, DEFAULT_LENGTH);
    }

    private static String getString(String characterType, int length) {
        int characterLength = characterType.length();

        int totalLength;
        if (length > 0) {
            totalLength = length;
        } else {
            totalLength = DEFAULT_LENGTH;
        }

        StringBuilder builder = new StringBuilder();
        int randomIndex;
        for (int index = 0; index < totalLength; index++) {
            randomIndex = getInt(characterLength);
            builder.append(characterType.charAt(randomIndex));
        }
        return builder.toString();
    }

    public static int getInt() {
        return sRandom.nextInt();
    }

    public static int getInt(int num) {
        return sRandom.nextInt(num);
    }

    public static double getDouble() {
        return getDouble(2);
    }

    public static double getDouble(int pointNum) {
        return getDouble(0, 1, pointNum);
    }

    public static double getDouble(double start, double end) {
        return getDouble(start, end, 2);
    }

    public static double getDouble(double start, double end, int pointNumber) {
        double temp = end - start;
        double value = sRandom.nextDouble() * temp + start;

        BigDecimal decimal = new BigDecimal(value);
        return decimal.setScale(pointNumber, BigDecimal.ROUND_HALF_UP)
                .doubleValue();
    }

    public static long getLong() {
        return sRandom.nextLong();
    }

    public static boolean getBoolean() {
        return sRandom.nextBoolean();
    }
}
