package com.cjw.demo1.utils;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public class ToastUtils {

    public static void shortShow(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public static void longShow(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
}
