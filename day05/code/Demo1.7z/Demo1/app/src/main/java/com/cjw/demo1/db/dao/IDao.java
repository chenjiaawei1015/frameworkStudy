package com.cjw.demo1.db.dao;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public interface IDao<T> {

    long insert(T entity) throws IllegalAccessException;

}
