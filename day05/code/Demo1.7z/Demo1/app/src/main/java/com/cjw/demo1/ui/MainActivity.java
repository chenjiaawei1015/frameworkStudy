package com.cjw.demo1.ui;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.cjw.demo1.R;
import com.cjw.demo1.bean.Person;
import com.cjw.demo1.db.dao.BaseDao;
import com.cjw.demo1.db.dao.BaseDaoFactory;
import com.cjw.demo1.ui.adapter.MainAdapter;
import com.cjw.demo1.utils.ToastUtils;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.reactivex.functions.Consumer;

public class MainActivity extends AppCompatActivity implements MainAdapter.OnItemClickListener {

    private Activity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mActivity = this;

        initRecyclerView();
        requestSdCardPermission();
    }

    private void requestSdCardPermission() {
        RxPermissions rxPermissions = new RxPermissions(mActivity);
        rxPermissions.request(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) throws Exception {
                        if (aBoolean) {
                            ToastUtils.shortShow(mActivity, "权限申请成功");
                        } else {
                            ToastUtils.shortShow(mActivity, "权限申请失败");
                        }
                    }
                });
    }

    private void initRecyclerView() {
        List<String> dataList = initData();

        RecyclerView mainRv = findViewById(R.id.main_rv);
        RecyclerView.LayoutManager manager = new LinearLayoutManager(mActivity);
        mainRv.setLayoutManager(manager);

        RecyclerView.ItemDecoration decoration = new DividerItemDecoration(mActivity,
                DividerItemDecoration.VERTICAL);
        mainRv.addItemDecoration(decoration);

        RecyclerView.Adapter adapter = new MainAdapter(dataList, this);
        mainRv.setAdapter(adapter);
    }

    private List<String> initData() {
        List<String> dataList = new ArrayList<>();
        Collections.addAll(dataList, "111");
        return dataList;
    }

    @Override
    public void onClick(int pos) {
        switch (pos) {
            case 0: {
                BaseDaoFactory instance = BaseDaoFactory.getInstance();
                BaseDao<Person> baseDao = instance.getBaseDao(Person.class);
                break;
            }

            default:
                break;
        }
    }
}
