package com.cjw.demo1.db.dao;

import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import java.io.File;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public class BaseDaoFactory {

    // 包名
    private static final String PACKAGE_NAME = "com.cjw.demo1";
    private static final String DATABASE_NAME = "cjw.db";

    private static BaseDaoFactory sBaseDaoFactoryInstance = new BaseDaoFactory();

    private SQLiteDatabase mSqLiteDatabase;

    private BaseDaoFactory() {
        createDataBase();
    }

    public static BaseDaoFactory getInstance() {
        return sBaseDaoFactoryInstance;
    }

    public <T> BaseDao getBaseDao(Class<T> entity) {
        if (entity == null) {
            return null;
        }

        try {
            BaseDao baseDao = BaseDao.class.newInstance();
            baseDao.init(mSqLiteDatabase, entity);
            return baseDao;
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void createDataBase() {
        File dirFile = new File(Environment.getExternalStorageDirectory(), PACKAGE_NAME);
        if (!dirFile.exists()) {
            dirFile.mkdirs();
        }
        File dbFile = new File(dirFile, DATABASE_NAME);
        mSqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
    }

}
