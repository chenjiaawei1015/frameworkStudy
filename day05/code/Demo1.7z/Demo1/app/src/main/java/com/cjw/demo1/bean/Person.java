package com.cjw.demo1.bean;

import com.cjw.demo1.db.annotation.DbField;
import com.cjw.demo1.db.annotation.DbTable;

@DbTable("tb_person")
public class Person {

    @DbField("_id")
    private Integer id;

    @DbField("name")
    private String userName;

    private Integer age;

    private Double money;

    public Person(int id, String userName, int age, double money) {
        this.id = id;
        this.userName = userName;
        this.age = age;
        this.money = money;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", age=" + age +
                ", money=" + money +
                '}';
    }
}
