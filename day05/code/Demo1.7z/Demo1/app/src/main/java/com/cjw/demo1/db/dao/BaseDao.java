package com.cjw.demo1.db.dao;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import com.cjw.demo1.Contants;
import com.cjw.demo1.db.annotation.DbField;
import com.cjw.demo1.db.annotation.DbTable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public class BaseDao<T> implements IDao<T> {

    // 是否创建了表
    private boolean mIsCreateTable;

    public void init(SQLiteDatabase database, Class<T> entity) {
        if (!database.isOpen()) {
            return;
        }

        if (!mIsCreateTable) {
            createTable(database, entity);
        }
    }

    private void createTable(SQLiteDatabase database, Class<T> entity) {
        // create table if not exists tb_user(_id integer,name varchar(20),password varchar(20))

        String tableName;
        DbTable tableAnnotation = entity.getAnnotation(DbTable.class);
        if (tableAnnotation == null) {
            tableName = entity.getSimpleName();
        } else {
            tableName = tableAnnotation.value();
        }

        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("create table if not exists ").append(tableName).append("(");

        Map<String, String> fieldTypeMap = getFieldTypeMap(entity);
        Set<Map.Entry<String, String>> fieldEntriesSet = fieldTypeMap.entrySet();
        for (Map.Entry<String, String> itemEntry : fieldEntriesSet) {
            String fieldKey = itemEntry.getKey();
            String fieldValue = itemEntry.getValue();
            sqlBuilder.append(fieldKey).append(" ").append(fieldValue).append(",");
        }

        int length = sqlBuilder.length();
        if (sqlBuilder.charAt(length - 1) == ',') {
            sqlBuilder.deleteCharAt(length - 1);
        }
        sqlBuilder.append(")");

        String sql = sqlBuilder.toString();
        Log.d(Contants.TAG, "创建表 sql : " + sql);

        database.execSQL(sql);
    }

    /**
     * 获取 数据库字段名 与 数据库字段类型 的对应关系
     */
    private Map<String, String> getFieldTypeMap(Class<T> entity) {
        // key -> 数据库字段名称
        // value -> 类型名称
        Map<String, String> fieldMap = new HashMap<>();
        String fieldKey;
        String fieldType;

        Field[] fields = entity.getDeclaredFields();
        for (Field itemField : fields) {
            itemField.setAccessible(true);
            DbField fieldAnnotation = itemField.getAnnotation(DbField.class);
            if (fieldAnnotation == null) {
                fieldKey = itemField.getName();
            } else {
                fieldKey = fieldAnnotation.value();
            }

            Class<?> type = itemField.getType();
            if (type.equals(String.class)) {
                fieldType = "TEXT";
            } else if (type.equals(Integer.class)) {
                fieldType = "INTEGER";
            } else if (type.equals(Double.class)) {
                fieldType = "DOUBLE";
            } else if (type.equals(Long.class)) {
                fieldType = "Long";
            } else {
                fieldType = "BLOB";
            }

            if (!TextUtils.isEmpty(fieldKey) && !TextUtils.isEmpty(fieldType)) {
                fieldMap.put(fieldKey, fieldType);
            }
        }
        return fieldMap;
    }

    @Override
    public long insert(T entity) {
        return 0;
    }
}
