package com.cjw.demo1.db.dao;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import com.cjw.demo1.Contants;
import com.cjw.demo1.db.annotation.DbField;
import com.cjw.demo1.db.annotation.DbTable;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class BaseDao<T> implements IDao<T> {

    // 是否创建了表
    private boolean mIsCreateTable;

    private SQLiteDatabase mSqliteDatabase;

    // key -> 数据库字段名
    // value -> 成员变量名
    private Map<String, String> mCacheMap;

    // 表名
    private String mTableName;

    public void init(SQLiteDatabase database, Class<T> entity) {
        mSqliteDatabase = database;
        if (!database.isOpen()) {
            throw new RuntimeException("不能多次进行初始化");
        }

        if (!mIsCreateTable) {
            createTable(database, entity);
            mIsCreateTable = true;

            initCacheMap(entity);
        }
    }

    private void initCacheMap(Class<T> entity) {
        mCacheMap = new HashMap<>();
        Field[] fields = entity.getDeclaredFields();
        String fieldKey;
        String fieldName;
        for (Field itemField : fields) {
            itemField.setAccessible(true);
            fieldName = itemField.getName();

            DbField fieldAnnotation = itemField.getAnnotation(DbField.class);
            if (fieldAnnotation == null) {
                fieldKey = fieldName;
            } else {
                fieldKey = fieldAnnotation.value();
            }

            mCacheMap.put(fieldKey, fieldName);
        }
    }

    private void createTable(SQLiteDatabase database, Class<T> entity) {
        // create table if not exists tb_user(_id integer,name varchar(20),password varchar(20))

        DbTable tableAnnotation = entity.getAnnotation(DbTable.class);
        if (tableAnnotation == null) {
            mTableName = entity.getSimpleName();
        } else {
            mTableName = tableAnnotation.value();
        }

        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("create table if not exists ").append(mTableName).append("(");

        Map<String, String> fieldTypeMap = getFieldTypeMap(entity);
        Set<Map.Entry<String, String>> fieldEntriesSet = fieldTypeMap.entrySet();
        for (Map.Entry<String, String> itemEntry : fieldEntriesSet) {
            String fieldKey = itemEntry.getKey();
            String fieldValue = itemEntry.getValue();
            sqlBuilder.append(fieldKey).append(" ").append(fieldValue).append(",");
        }

        int length = sqlBuilder.length();
        if (sqlBuilder.charAt(length - 1) == ',') {
            sqlBuilder.deleteCharAt(length - 1);
        }
        sqlBuilder.append(")");

        String sql = sqlBuilder.toString();
        Log.d(Contants.TAG, "创建表 sql : " + sql);

        database.execSQL(sql);
    }

    /**
     * 获取 数据库字段名 与 数据库字段类型 的对应关系
     */
    private Map<String, String> getFieldTypeMap(Class<T> entity) {
        // key -> 数据库字段名称
        // value -> 类型名称
        Map<String, String> fieldMap = new HashMap<>();
        String fieldKey;
        String fieldType;

        Field[] fields = entity.getDeclaredFields();
        for (Field itemField : fields) {
            itemField.setAccessible(true);
            DbField fieldAnnotation = itemField.getAnnotation(DbField.class);
            if (fieldAnnotation == null) {
                fieldKey = itemField.getName();
            } else {
                fieldKey = fieldAnnotation.value();
            }

            Class<?> type = itemField.getType();
            if (type.equals(String.class)) {
                fieldType = "TEXT";
            } else if (type.equals(Integer.class)) {
                fieldType = "INTEGER";
            } else if (type.equals(Double.class)) {
                fieldType = "DOUBLE";
            } else if (type.equals(Long.class)) {
                fieldType = "Long";
            } else {
                fieldType = "BLOB";
            }

            if (!TextUtils.isEmpty(fieldKey) && !TextUtils.isEmpty(fieldType)) {
                fieldMap.put(fieldKey, fieldType);
            }
        }
        return fieldMap;
    }

    @Override
    public long insert(T entity) throws IllegalAccessException {
        ContentValues contentValues = new ContentValues();

        // key -> 数据库字段名
        // value -> 值
        Map<String, String> fieldValueMap = generateMapForEntity(entity);
        Set<Map.Entry<String, String>> entries = fieldValueMap.entrySet();
        for (Map.Entry<String, String> itemEntries : entries) {
            String key = itemEntries.getKey();
            String value = itemEntries.getValue();
            contentValues.put(key, value);
        }
        return mSqliteDatabase.insert(mTableName, null, contentValues);
    }

    private Map<String, String> generateMapForEntity(T entity) throws IllegalAccessException {
        // key -> 数据库字段名
        // value -> 值
        Map<String, String> fieldValueMap = new HashMap<>();

        Field[] fields = entity.getClass().getDeclaredFields();
        String key;
        String value;
        for (Field itemField : fields) {
            itemField.setAccessible(true);

            DbField dbFieldAnnotation = itemField.getAnnotation(DbField.class);
            if (dbFieldAnnotation == null) {
                key = itemField.getName();
            } else {
                key = dbFieldAnnotation.value();
            }
            value = itemField.get(entity).toString();
            fieldValueMap.put(key, value);
        }

        return fieldValueMap;
    }
}
