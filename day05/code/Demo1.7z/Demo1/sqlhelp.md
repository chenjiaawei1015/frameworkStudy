# sql语句

## 建表
create table if not exists tb_user(_id integer,name varchar(20),password varchar(20))

## 查看所有表
.table

## 查看表结构
select * from sqlite_master where type="table" and name="表名"

## 查看某张表的列数
select count(*) from 表名

## 退出
.quit