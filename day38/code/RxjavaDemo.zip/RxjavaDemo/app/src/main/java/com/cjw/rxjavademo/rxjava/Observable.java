package com.cjw.rxjavademo.rxjava;

/**
 * 被观察者
 *
 * @author chenjiawei
 */
public class Observable<T> {

    private ObservableOnSubscribe<T> mOnSubscribe;

    public Observable(ObservableOnSubscribe<T> onSubscribe) {
        mOnSubscribe = onSubscribe;
    }

    public static <T> Observable<T> create(ObservableOnSubscribe<T> onSubscribe) {
        return (Observable<T>) new Observable(onSubscribe);
    }

    public void subscribe(Observer<T> observable) {
        mOnSubscribe.subscribe(observable);
    }

}
