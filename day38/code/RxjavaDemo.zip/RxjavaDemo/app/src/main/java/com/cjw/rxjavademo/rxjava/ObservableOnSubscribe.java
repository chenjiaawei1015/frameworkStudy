package com.cjw.rxjavademo.rxjava;

public interface ObservableOnSubscribe<T> {

    void subscribe(Emitter<T> emitter);

}
