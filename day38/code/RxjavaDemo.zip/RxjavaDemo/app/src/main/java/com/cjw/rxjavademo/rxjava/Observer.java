package com.cjw.rxjavademo.rxjava;

public interface Observer<T> extends Emitter<T> {

}
