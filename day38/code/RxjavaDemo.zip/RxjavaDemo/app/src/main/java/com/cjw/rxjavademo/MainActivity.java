package com.cjw.rxjavademo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.cjw.rxjavademo.rxjava.Emitter;
import com.cjw.rxjavademo.rxjava.Observable;
import com.cjw.rxjavademo.rxjava.ObservableOnSubscribe;
import com.cjw.rxjavademo.rxjava.Observer;

/**
 * @author chenjiawei
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void testMyCreate(View view) {
        Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(Emitter<String> emitter) {
                emitter.onNext("test1");
                emitter.onNext("test2");
                emitter.onComplete();
            }
        }).subscribe(new Observer<String>() {
            @Override
            public void onNext(String value) {
                System.out.println("onNext : " + value);
            }

            @Override
            public void onError(Throwable error) {
                error.printStackTrace();
            }

            @Override
            public void onComplete() {
                System.out.println("onComplete");
            }
        });
    }
}
