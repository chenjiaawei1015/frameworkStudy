package com.cjw.servicedemo;

import android.os.RemoteException;

/**
 * Created by chenjiawei on 2018/4/8.
 */

public class PersonService extends IPerson.Stub {

    private String mName;

    @Override
    public String getName() throws RemoteException {
        return mName;
    }

    @Override
    public void setName(String name) throws RemoteException {
        mName = name;
    }
}
