package com.cjw.servicedemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

/**
 * Created by chenjiawei on 2018/4/8.
 */

public class AppService extends Service {

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new PersonService();
    }
}
