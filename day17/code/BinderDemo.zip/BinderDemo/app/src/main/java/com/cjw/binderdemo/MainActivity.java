package com.cjw.binderdemo;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.cjw.servicedemo.IPerson;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "cjw";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void bindAppService(View view) {
        Intent intent = new Intent();
        intent.setPackage("com.cjw.servicedemo");
        intent.setAction("com.cjw.servicedemo.PersonService");

        bindService(intent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                IPerson iPerson = IPerson.Stub.asInterface(service);

                String username = RandomUtils.getString(3);
                Log.d(TAG, "username 设置的值 : " + username);

                try {
                    iPerson.setName(username);

                    String queryName = iPerson.getName();
                    Log.d(TAG, "username 取出的值 : " + queryName);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        }, Context.BIND_AUTO_CREATE);
    }
}
