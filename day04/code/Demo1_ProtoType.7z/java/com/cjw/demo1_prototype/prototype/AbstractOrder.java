package com.cjw.demo1_prototype.prototype;

/**
 * Created by Administrator on 2018/3/6.
 */

public abstract class AbstractOrder implements IOrderCloneable {

    protected String mOrderName;
    protected int mOrderNum;

    public int getOrderNum() {
        return mOrderNum;
    }

    public void setOrderNum(int orderNum) {
        mOrderNum = orderNum;
    }

    public String getOrderName() {
        return mOrderName;
    }

    public void setOrderName(String orderName) {
        mOrderName = orderName;
    }
}
