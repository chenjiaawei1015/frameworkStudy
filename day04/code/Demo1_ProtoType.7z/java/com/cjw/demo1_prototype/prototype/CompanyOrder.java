package com.cjw.demo1_prototype.prototype;

/**
 * Created by Administrator on 2018/3/6.
 */

public class CompanyOrder extends AbstractOrder {

    @Override
    public AbstractOrder cloneOrder() {
        CompanyOrder order = new CompanyOrder();
        order.setOrderName(this.mOrderName);
        order.setOrderNum(this.mOrderNum);
        return order;
    }
}
