package com.cjw.demo1_prototype.prototype;

/**
 * Created by Administrator on 2018/3/6.
 */

public class PersonOrder extends AbstractOrder {

    @Override
    public AbstractOrder cloneOrder() {
        PersonOrder order = new PersonOrder();
        order.setOrderName(this.mOrderName);
        order.setOrderNum(this.mOrderNum);
        return order;
    }
}
