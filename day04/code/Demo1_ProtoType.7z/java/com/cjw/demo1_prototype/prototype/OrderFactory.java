package com.cjw.demo1_prototype.prototype;

import java.util.Locale;

/**
 * Created by Administrator on 2018/3/6.
 */

public class OrderFactory {

    private static final int MAX_ONE_MAKE_ORDER_COUNT = 300;

    public void startMakeOrder(AbstractOrder order) {
        int orderNum = order.getOrderNum();

        String formatStr = String.format(Locale.CHINA, "原始数据 地址:%s , 名称:%s , 数量:%d",
                order, order.getOrderName(), order.getOrderNum());
        System.out.println(formatStr);

        AbstractOrder cloneOrder;
        while (orderNum > 0) {
            cloneOrder = order.cloneOrder();
            if (MAX_ONE_MAKE_ORDER_COUNT < orderNum) {
                cloneOrder.setOrderNum(MAX_ONE_MAKE_ORDER_COUNT);
            } else {
                cloneOrder.setOrderNum(orderNum);
            }

            formatStr = String.format(Locale.CHINA, "地址:%s , 名称:%s , 数量:%d",
                    cloneOrder, cloneOrder.getOrderName(), cloneOrder.getOrderNum());
            System.out.println(formatStr);

            orderNum -= MAX_ONE_MAKE_ORDER_COUNT;
        }
    }

}
