package com.cjw.demo1_prototype.prototype;

/**
 * Created by Administrator on 2018/3/6.
 */

public interface IOrderCloneable {

    AbstractOrder cloneOrder();
}
