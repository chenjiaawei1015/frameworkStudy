package com.cjw.demo1_prototype.prototype;

import org.junit.Test;

/**
 * Created by Administrator on 2018/3/6.
 */

public class Client {

    @Test
    public void testClone() {
        OrderFactory factory = new OrderFactory();

        AbstractOrder personOrder = new PersonOrder();
        personOrder.setOrderName("person order");
        personOrder.setOrderNum(1000);
        // factory.startMakeOrder(personOrder);

        AbstractOrder companyOrder = new CompanyOrder();
        companyOrder.setOrderName("company order");
        companyOrder.setOrderNum(500);
        factory.startMakeOrder(companyOrder);
    }

}
