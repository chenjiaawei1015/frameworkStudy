package com.cjw.demo2_aop;

import android.util.Log;

import com.cjw.demo2_aop.annotation.BehaviorTrace;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

/**
 * 切面
 * Created by Administrator on 2018/3/6.
 */

// 用 @Aspect 注解表示当前是一个切面
@Aspect
public class BehaviorTraceAspect {

    // 切点
    // 用于处理 哪些切点 哪些地方需要处理
    // 格式 execution(@注解全名称 哪些类上需要进行处理 哪些方法上需要进行处理(方法参数个数的限定))
    // * *(..)
    // 第一个 * , 这里代表任意类
    // 第二个 * , 这里代表任意方法
    // ()中的 .. , 代表不限定方法参数的个数
    @Pointcut(value = "execution(@com.cjw.demo2_aop.annotation.BehaviorTrace * *(..))")
    public void methodAnnotationTrace() {
    }

    // 如何进行处理
    // 可以使用三种注解 @Around @Before @After , 代表在什么时候进行调用
    // 注解参数的值必须为切点的方法名称
    // 返回值必须为 Object
    // 参数必须只有一个,且参数的类型必须为 ProceedingJoinPoint
    // 异常需要抛出 Throwable 异常
    @Around(value = "methodAnnotationTrace()")
    public Object doTask(ProceedingJoinPoint joinPoint) throws Throwable {
        // 获取耗时时间
        long begin = System.currentTimeMillis();
        Object res = joinPoint.proceed();
        long duration = System.currentTimeMillis() - begin;

        // 获取注解处理器上的属性值
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        BehaviorTrace trace = method.getAnnotation(BehaviorTrace.class);
        String function = trace.value();

        Log.i("cjw", function + " , 耗时 : " + duration);
        return res;
    }
}
