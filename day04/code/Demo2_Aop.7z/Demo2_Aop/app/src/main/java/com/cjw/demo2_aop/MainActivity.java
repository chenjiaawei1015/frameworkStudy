package com.cjw.demo2_aop;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.cjw.demo2_aop.annotation.BehaviorTrace;

import java.security.SecureRandom;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @BehaviorTrace("短信")
    public void onMessageClick(View view) {
        doBackgroundTask();
    }

    @BehaviorTrace("语音")
    public void onVoiceClick(View view) {
        doBackgroundTask();
    }

    public void onVideoClick(View view) {
        doBackgroundTask();
    }

    public void doBackgroundTask() {
        int delayTime = RandomUtils.getInt(2000);
        SystemClock.sleep(delayTime);
    }
}
