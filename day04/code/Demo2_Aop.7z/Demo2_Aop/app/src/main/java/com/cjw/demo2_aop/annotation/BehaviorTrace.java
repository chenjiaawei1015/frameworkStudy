package com.cjw.demo2_aop.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 用户行为统计注解
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface BehaviorTrace {
    String value();
}

// 注解的定义
// @interface 注解名

// @Target 表示注解使用在哪个地方
// 属性值 ElementType.xxx
// TYPE 类
// FIELD 属性
// METHOD 方法
// PARAMETER 参数
// CONSTRUCTOR 构造方法
// LOCAL_VARIABLE 局部变量
// ANNOTATION_TYPE 注解
// PACKAGE 包

// @Retention 表示注解的保留阶段
// 属性值 RetentionPolicy.xxx
// SOURCE 只在源码阶段保留,即编译阶段 (如: @onCreate)
// CLASS 只在 class 阶段保留 (如一些第三方编译时框架 ButterKnife 中的 @BindView)
// RUNTIME 运行程序的时候依然保留,即运行时阶段