package com.cjw.demo1;

import android.app.Application;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import com.orhanobut.logger.Logger;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class HookUtils {

  private static final String KEY_COMPONENT_NAME = "key.ComponentName";
  private static final String PACKAGE_NAME = "com.cjw.demo1";
  private static final String PROXY_ACTIVITY_CLASS_NAME = "com.cjw.demo1.ProxyActivity";
  private static final int LAUNCH_ACTIVITY = 100;

  public void hookStartActivity(Application application) {
    try {
      Class<?> ActivityManagerNativeClazz = Class.forName("android.app.ActivityManagerNative");
      Field gDefaultField = ActivityManagerNativeClazz.getDeclaredField("gDefault");
      gDefaultField.setAccessible(true);
      // Singleton<IActivityManager>
      Object gDefaultObj = gDefaultField.get(null);

      Class<?> singletonClazz = Class.forName("android.util.Singleton");
      Field mInstanceField = singletonClazz.getDeclaredField("mInstance");
      mInstanceField.setAccessible(true);
      // IActivityManager
      Object iActivityManagerObj = mInstanceField.get(gDefaultObj);

      Class<?> iActivityManagerClazz = Class.forName("android.app.IActivityManager");

      ClassLoader classLoader = application.getClassLoader();
      StartActivityInvocationHandler invocationHandler = new StartActivityInvocationHandler(iActivityManagerObj);
      Object iActivityManagerProxy =
          Proxy.newProxyInstance(classLoader, new Class[] { iActivityManagerClazz }, invocationHandler);

      mInstanceField.set(gDefaultObj, iActivityManagerProxy);

      Logger.d("hookStartActivity success");
    } catch (Exception e) {
      e.printStackTrace();
      Logger.e(e.getMessage());
    }
  }

  public void hookActivityThreadHandler() {
    try {
      Logger.d("begin hookActivityThreadHandler");

      Class<?> activityThreadClazz = Class.forName("android.app.ActivityThread");

      Field sCurrentActivityThreadField = activityThreadClazz.getDeclaredField("sCurrentActivityThread");
      sCurrentActivityThreadField.setAccessible(true);
      Object sCurrentActivityThread = sCurrentActivityThreadField.get(null);

      Field mHField = activityThreadClazz.getDeclaredField("mH");
      mHField.setAccessible(true);
      Object mH = mHField.get(sCurrentActivityThread);

      if (mH instanceof Handler) {
        // 给mH设置callback回调
        MyHandlerCallBack callBack = new MyHandlerCallBack((Handler) mH);

        Field mCallbackField = Handler.class.getDeclaredField("mCallback");
        mCallbackField.setAccessible(true);
        mCallbackField.set(mH, callBack);

        Logger.d("ActivityThread mH 设置 callback 成功");
      }
    } catch (Exception e) {
      Logger.d("ActivityThread mH 设置 callback 失败");
      e.printStackTrace();
    }
  }

  private class StartActivityInvocationHandler implements InvocationHandler {

    private Object mIActivityManagerObj;

    StartActivityInvocationHandler(Object iActivityManagerObj) {
      mIActivityManagerObj = iActivityManagerObj;
    }

    @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
      String methodName = method.getName();
      if (TextUtils.equals(methodName, "startActivity")) {
        Logger.d("开始 hook startActivity");

        Intent intent = null;
        int intentIndex = -1;

        for (int index = 0; index < args.length; index++) {
          if (args[index] instanceof Intent) {
            intent = (Intent) args[index];
            intentIndex = index;
            break;
          }
        }

        if (intent != null) {
          ComponentName componentName = intent.getComponent();

          Intent proxyIntent = new Intent();
          ComponentName proxyComponentName = new ComponentName(PACKAGE_NAME, PROXY_ACTIVITY_CLASS_NAME);
          proxyIntent.setComponent(proxyComponentName);
          proxyIntent.putExtra(KEY_COMPONENT_NAME, componentName);

          args[intentIndex] = proxyIntent;

          Logger.d("替换 intent 成功");
        }
      }
      return method.invoke(mIActivityManagerObj, args);
    }
  }

  private class MyHandlerCallBack implements Handler.Callback {

    private Handler mHandler;

    public MyHandlerCallBack(Handler handler) {
      mHandler = handler;
    }

    @Override public boolean handleMessage(Message msg) {
      if (LAUNCH_ACTIVITY == msg.what) {
        Logger.d("开始 hook handler 100 message");

        try {
          Class<?> ActivityClientRecordClazz = msg.obj.getClass();
          Field intentField = ActivityClientRecordClazz.getDeclaredField("intent");
          intentField.setAccessible(true);
          Intent intent = (Intent) intentField.get(msg.obj);

          ComponentName componentName = intent.getParcelableExtra(KEY_COMPONENT_NAME);
          if (componentName != null) {
            Intent realIntent = new Intent();
            realIntent.setComponent(componentName);

            intentField.set(msg.obj, realIntent);
            Logger.d("hook handler 100 message 成功");
          }
        } catch (Exception e) {
          e.printStackTrace();
          Logger.d("hook handler 100 message 失败");
        }
      }
      mHandler.handleMessage(msg);
      return true;
    }
  }
}
