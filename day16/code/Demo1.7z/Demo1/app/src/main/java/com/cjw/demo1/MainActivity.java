package com.cjw.demo1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

  private TextView mTitleTv;
  private Button mJumpTestBt;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    mTitleTv = findViewById(R.id.title_tv);
    mJumpTestBt = findViewById(R.id.jump_test_bt);

    mJumpTestBt.setOnClickListener(this);
  }

  @Override
  public void onClick(View v) {
    switch (v.getId()) {
      case R.id.jump_test_bt: {
        Intent intent = new Intent(this, TestActivity.class);
        startActivity(intent);
        break;
      }

      default:
        break;
    }
  }
}
