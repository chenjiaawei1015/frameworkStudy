package com.cjw.taopiaopiao;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends BaseActivity {

  public static final String ACTION1 = "action1";

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    findViewById(R.id.toast_bt).setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Toast.makeText(mProxyActivity, "toast", Toast.LENGTH_SHORT).show();
      }
    });

    findViewById(R.id.jump_bt).setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(mProxyActivity, SecondActivity.class);
        startActivity(intent);
      }
    });

    findViewById(R.id.open_server_bt).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        Intent intent = new Intent(mProxyActivity, MainService.class);
        startService(intent);
      }
    });

    findViewById(R.id.receiver_bt).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION1);
        registerReceiver(new MyReceiver(), filter);
      }
    });

    findViewById(R.id.send_bt).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        Intent intent = new Intent();
        intent.setAction(ACTION1);
        sendBroadcast(intent);
      }
    });

    findViewById(R.id.send_static_bt).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        Intent intent = new Intent();
        intent.setAction("cjw1");
        sendBroadcast(intent);
      }
    });

    findViewById(R.id.send_static2_bt).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        Intent intent = new Intent();
        intent.setAction("cjw2");
        sendBroadcast(intent);
      }
    });
  }
}
