package com.cjw.taopiaopiao;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import com.cjw.pluginstand.IPayActivity;

public abstract class BaseActivity extends Activity implements IPayActivity {

  protected Activity mProxyActivity;

  @Override public void attach(Activity proxyActivity) {
    mProxyActivity = proxyActivity;
  }

  @Override public void setContentView(int layoutResID) {
    mProxyActivity.setContentView(layoutResID);
  }

  @Override public void setContentView(View view) {
    mProxyActivity.setContentView(view);
  }

  @Override public <T extends View> T findViewById(int id) {
    return mProxyActivity.findViewById(id);
  }

  @Override public Intent getIntent() {
    return mProxyActivity.getIntent();
  }

  @Override public ClassLoader getClassLoader() {
    return mProxyActivity.getClassLoader();
  }

  @Override public Resources getResources() {
    return mProxyActivity.getResources();
  }

  @NonNull @Override public LayoutInflater getLayoutInflater() {
    return mProxyActivity.getLayoutInflater();
  }

  @Override public ApplicationInfo getApplicationInfo() {
    return mProxyActivity.getApplicationInfo();
  }

  @Override public Window getWindow() {
    return mProxyActivity.getWindow();
  }

  @Override public WindowManager getWindowManager() {
    return mProxyActivity.getWindowManager();
  }

  @Override public void startActivity(Intent intent) {
    ComponentName component = intent.getComponent();
    if (component == null) {
      return;
    }

    String name = component.getClassName();

    Intent newIntent = new Intent();
    newIntent.putExtra(IPayActivity.KEY_CLASS_NAME, name);
    mProxyActivity.startActivity(newIntent);
  }

  @Override public ComponentName startService(Intent service) {
    ComponentName component = service.getComponent();
    if (component == null) {
      return null;
    }

    String name = component.getClassName();
    Intent newIntent = new Intent();
    newIntent.putExtra(IPayActivity.KEY_CLASS_NAME, name);
    return mProxyActivity.startService(newIntent);
  }

  @Override public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
    if (mProxyActivity == null) {
      return super.registerReceiver(receiver, filter);
    }
    return mProxyActivity.registerReceiver(receiver, filter);
  }

  @Override public void sendBroadcast(Intent intent) {
    mProxyActivity.sendBroadcast(intent);
  }

  @Override public void onCreate(Bundle savedInstanceState) {

  }

  @Override public void onStart() {

  }

  @Override public void onResume() {

  }

  @Override public void onPause() {

  }

  @Override public void onStop() {

  }

  @Override public void onDestroy() {

  }

  @Override public void onSaveInstanceState(Bundle outState) {

  }
}
