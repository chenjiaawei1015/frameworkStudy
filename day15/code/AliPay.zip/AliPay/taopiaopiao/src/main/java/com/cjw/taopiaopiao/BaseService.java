package com.cjw.taopiaopiao;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import com.cjw.pluginstand.IPayService;

public abstract class BaseService extends Service implements IPayService {

  protected Service mProxyService;

  @Override public void attach(Service proxyService) {
    mProxyService = proxyService;
  }

  @Nullable @Override public IBinder onBind(Intent intent) {
    return null;
  }
}
