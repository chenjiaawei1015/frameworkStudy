package com.cjw.taopiaopiao;

import android.app.Activity;
import android.content.BroadcastReceiver;
import com.cjw.pluginstand.IPayReceiver;

/**
 * Created by chenjiawei on 2018/4/2.
 */

public abstract class BaseReceiver extends BroadcastReceiver implements IPayReceiver {

  protected Activity mProxyActivity;

  @Override public void attach(Activity proxyActivity) {
    mProxyActivity = proxyActivity;
  }
}
