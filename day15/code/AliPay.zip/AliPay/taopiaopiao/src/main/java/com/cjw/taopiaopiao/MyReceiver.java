package com.cjw.taopiaopiao;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by chenjiawei on 2018/4/2.
 */

public class MyReceiver extends BaseReceiver {

  @Override public void onReceive(Context context, Intent intent) {
    Toast.makeText(mProxyActivity, "插件收到广播1", Toast.LENGTH_SHORT).show();
  }
}
