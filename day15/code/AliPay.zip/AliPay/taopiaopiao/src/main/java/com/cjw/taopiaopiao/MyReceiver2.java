package com.cjw.taopiaopiao;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by chenjiawei on 2018/4/2.
 */

public class MyReceiver2 extends BroadcastReceiver {

  @Override public void onReceive(Context context, Intent intent) {
    String action = intent.getAction();
    Toast.makeText(context, "插件收到广播2 , action : " + action, Toast.LENGTH_SHORT).show();
  }
}
