package com.cjw.alipay;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import com.cjw.pluginstand.IPayService;
import com.cjw.pluginstand.LogUtils;
import dalvik.system.DexClassLoader;
import java.lang.reflect.Constructor;

public class ProxyService extends Service {

  private IPayService mService;

  @Override public void onCreate() {
    super.onCreate();
    LogUtils.debug("onCreate");
  }

  @Nullable @Override public IBinder onBind(Intent intent) {
    String className = intent.getStringExtra(IPayService.KEY_CLASS_NAME);

    DexClassLoader dexClassLoader = PluginManager.getInstance().getDexClassLoader();
    try {
      Class<?> serviceClazz = dexClassLoader.loadClass(className);
      Constructor<?> constructor = serviceClazz.getDeclaredConstructor();
      constructor.setAccessible(true);
      mService = (IPayService) constructor.newInstance();

      mService.attach(this);
      mService.onCreate();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return mService.onBind(intent);
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (mService == null) {
      onBind(intent);
    }
    return mService.onStartCommand(intent, flags, startId);
  }

  @Override public boolean onUnbind(Intent intent) {
    if (mService == null) {
      return super.onUnbind(intent);
    }
    return mService.onUnbind(intent);
  }

  @Override public void onDestroy() {
    if (mService == null) {
      super.onDestroy();
      return;
    }
    mService.onDestroy();
  }

  @Override public void onRebind(Intent intent) {
    if (mService == null) {
      super.onDestroy();
      return;
    }
    mService.onRebind(intent);
  }
}
