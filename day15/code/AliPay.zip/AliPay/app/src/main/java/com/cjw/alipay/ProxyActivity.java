package com.cjw.alipay;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Window;
import com.cjw.pluginstand.IPayActivity;
import com.cjw.pluginstand.IPayService;
import dalvik.system.DexClassLoader;

public class ProxyActivity extends AppCompatActivity {

  public static final String KEY_BUNDLE = "bundle";
  private IPayActivity mPluginActivity;

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    super.onCreate(savedInstanceState);

    Intent intent = getIntent();
    String activityClazzName = intent.getStringExtra(IPayActivity.KEY_CLASS_NAME);
    Bundle bundle = intent.getBundleExtra(KEY_BUNDLE);

    DexClassLoader dexClassLoader = PluginManager.getInstance().getDexClassLoader();
    try {
      Class activityClazz = dexClassLoader.loadClass(activityClazzName);
      mPluginActivity = (IPayActivity) activityClazz.newInstance();

      mPluginActivity.attach(this);
      mPluginActivity.onCreate(bundle);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override public void startActivity(Intent intent) {
    String clazzName = intent.getStringExtra(IPayActivity.KEY_CLASS_NAME);
    if (TextUtils.isEmpty(clazzName)) {
      return;
    }

    Intent newIntent = new Intent(this, ProxyActivity.class);
    newIntent.putExtra(IPayActivity.KEY_CLASS_NAME, clazzName);
    newIntent.putExtra(KEY_BUNDLE, new Bundle());
    super.startActivity(newIntent);
  }

  @Override public ComponentName startService(Intent service) {
    String clazzName = service.getStringExtra(IPayActivity.KEY_CLASS_NAME);
    if (TextUtils.isEmpty(clazzName)) {
      return null;
    }

    Intent intent = new Intent(this, ProxyService.class);
    intent.putExtra(IPayService.KEY_CLASS_NAME, clazzName);
    return super.startService(intent);
  }

  @Override public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
    ProxyReceiver proxyReceiver = new ProxyReceiver(this, receiver.getClass().getName());
    return super.registerReceiver(proxyReceiver, filter);
  }

  @Override public void sendBroadcast(Intent intent) {
    super.sendBroadcast(intent);
  }

  @Override public Resources getResources() {
    return PluginManager.getInstance().getPluginResource();
  }

  @Override public ClassLoader getClassLoader() {
    return PluginManager.getInstance().getDexClassLoader();
  }

  @Override protected void onStart() {
    super.onStart();
    mPluginActivity.onStart();
  }

  @Override protected void onResume() {
    super.onResume();
    mPluginActivity.onResume();
  }

  @Override protected void onPause() {
    super.onPause();
    mPluginActivity.onPause();
  }

  @Override protected void onStop() {
    super.onStop();
    mPluginActivity.onStop();
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    mPluginActivity.onDestroy();
  }
}
