package com.cjw.alipay;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import com.cjw.pluginstand.LogUtils;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

public class PluginManager {

  private static PluginManager sPluginManager = new PluginManager();

  private Resources mPluginResource;
  private PackageInfo mPackageInfo;
  private DexClassLoader mDexClassLoader;

  private PluginManager() {
  }

  public static PluginManager getInstance() {
    return sPluginManager;
  }

  public void loadPlugin(Activity activity, String path) {
    try {
      Constructor<AssetManager> constructor = AssetManager.class.getDeclaredConstructor();
      constructor.setAccessible(true);
      AssetManager assetManager = constructor.newInstance();

      Method addAssetPathMethod =
          AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
      addAssetPathMethod.setAccessible(true);
      addAssetPathMethod.invoke(assetManager, path);

      Context applicationContext = activity.getApplicationContext();
      Resources resources = applicationContext.getResources();
      mPluginResource = new Resources(assetManager, resources.getDisplayMetrics(),
          resources.getConfiguration());

      PackageManager packageManager = applicationContext.getPackageManager();
      mPackageInfo = packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES);

      File optFile = new File(activity.getCacheDir(), "opt");
      if (!optFile.exists()) {
        optFile.mkdirs();
      }
      mDexClassLoader = new DexClassLoader(path, optFile.getAbsolutePath(), null,
          activity.getClassLoader());

      loadReceiver(activity, path);

      LogUtils.debug("加载成功");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * 加载插件中的静态广播
   */
  private void loadReceiver(Activity activity, String path) {
    try {
      Class packageParserClazz = Class.forName("android.content.pm.PackageParser");
      Constructor constructor = packageParserClazz.getDeclaredConstructor();
      constructor.setAccessible(true);
      Object packageParser = constructor.newInstance();

      Method parsePackageMethod =
          packageParserClazz.getDeclaredMethod("parsePackage", File.class, int.class);
      parsePackageMethod.setAccessible(true);

      File scanFile = new File(path);
      Object packageParserPackage =
          parsePackageMethod.invoke(packageParser, scanFile, PackageManager.GET_ACTIVITIES);

      Class<?> packageClazz = packageParserPackage.getClass();
      Field receiversField = packageClazz.getDeclaredField("receivers");
      receiversField.setAccessible(true);
      List receivers = (List) receiversField.get(packageParserPackage);

      for (Object receiverActivity : receivers) {
        Field infoField = receiverActivity.getClass().getDeclaredField("info");
        infoField.setAccessible(true);
        ActivityInfo info = (ActivityInfo) infoField.get(receiverActivity);
        String receiverName = info.name;

        Field intentsField = receiverActivity.getClass().getField("intents");
        List<? extends IntentFilter> intentFilters =
            (List<? extends IntentFilter>) intentsField.get(receiverActivity);

        for (IntentFilter filter : intentFilters) {
          Class<?> receiverClazz = mDexClassLoader.loadClass(receiverName);
          BroadcastReceiver receiver = (BroadcastReceiver) receiverClazz.newInstance();
          activity.registerReceiver(receiver, filter);
        }
      }

      LogUtils.debug("注册成功");

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Resources getPluginResource() {
    return mPluginResource;
  }

  public PackageInfo getPackageInfo() {
    return mPackageInfo;
  }

  public DexClassLoader getDexClassLoader() {
    return mDexClassLoader;
  }
}
