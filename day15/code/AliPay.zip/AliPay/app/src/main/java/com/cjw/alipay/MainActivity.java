package com.cjw.alipay;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import com.cjw.pluginstand.IPayActivity;
import java.io.File;

public class MainActivity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
  }

  /**
   * 加载插件
   */
  public void loadPlugin(View view) {
    File file = new File(Environment.getExternalStorageDirectory(), "taopiaopiao-debug.apk");
    String path = file.getAbsolutePath();
    PluginManager.getInstance().loadPlugin(this, path);
  }

  /**
   * 打开插件页面
   */
  public void openPlugin(View view) {
    ActivityInfo pluginActivity = PluginManager.getInstance().getPackageInfo().activities[0];
    String activityClazzName = pluginActivity.name;

    Intent intent = new Intent(this, ProxyActivity.class);
    intent.putExtra(IPayActivity.KEY_CLASS_NAME, activityClazzName);
    intent.putExtra(ProxyActivity.KEY_BUNDLE, new Bundle());
    startActivity(intent);
  }
}
