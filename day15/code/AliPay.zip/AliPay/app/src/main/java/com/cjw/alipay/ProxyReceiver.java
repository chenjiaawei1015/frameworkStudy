package com.cjw.alipay;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.cjw.pluginstand.IPayReceiver;
import dalvik.system.DexClassLoader;
import java.lang.reflect.Constructor;

/**
 * Created by chenjiawei on 2018/4/2.
 */

public class ProxyReceiver extends BroadcastReceiver {

  public String mClassName;
  private IPayReceiver mReceiver;

  public ProxyReceiver(Activity activity, String mClassName) {
    this.mClassName = mClassName;

    DexClassLoader dexClassLoader = PluginManager.getInstance().getDexClassLoader();
    try {
      Class<?> receiverClazz = dexClassLoader.loadClass(mClassName);
      Constructor<?> constructor = receiverClazz.getDeclaredConstructor();
      constructor.setAccessible(true);

      mReceiver = (IPayReceiver) constructor.newInstance();
      mReceiver.attach(activity);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override public void onReceive(Context context, Intent intent) {
    mReceiver.onReceive(context, intent);
  }
}
