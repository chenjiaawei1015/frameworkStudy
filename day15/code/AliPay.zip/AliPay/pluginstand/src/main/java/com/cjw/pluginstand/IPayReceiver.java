package com.cjw.pluginstand;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

/**
 * Created by chenjiawei on 2018/4/2.
 */

public interface IPayReceiver {

  void attach(Activity proxyActivity);

  void onReceive(Context context, Intent intent);
}
