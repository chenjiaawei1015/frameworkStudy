package com.cjw.pluginstand;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;

public interface IPayActivity {

  String KEY_CLASS_NAME = "className";

  void attach(Activity proxyActivity);

  /**
   * 生命周期
   */
  void onCreate(Bundle savedInstanceState);

  void onStart();

  void onResume();

  void onPause();

  void onStop();

  void onDestroy();

  void onSaveInstanceState(Bundle outState);

  boolean onTouchEvent(MotionEvent event);

  void onBackPressed();
}
