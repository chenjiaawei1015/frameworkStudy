package com.cjw.demo1.ui;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.cjw.demo1.Contants;
import com.cjw.demo1.R;
import com.cjw.demo1.bean.Person;
import com.cjw.demo1.db.dao.BaseDao;
import com.cjw.demo1.db.dao.BaseDaoFactory;
import com.cjw.demo1.db.dao.PersonDao;
import com.cjw.demo1.ui.adapter.MainAdapter;
import com.cjw.demo1.utils.RandomUtils;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.reactivex.functions.Consumer;

public class MainActivity extends AppCompatActivity implements MainAdapter.OnItemClickListener {

    private Activity mActivity;
    private List<String> mDataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mActivity = this;

        initRecyclerView();
        requestSdCardPermission();
    }

    private void requestSdCardPermission() {
        RxPermissions rxPermissions = new RxPermissions(mActivity);
        rxPermissions.request(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .subscribe(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) throws Exception {
                        if (aBoolean) {
                            Log.d(Contants.TAG, "权限申请成功");
                        } else {
                            Log.d(Contants.TAG, "权限申请失败");
                        }
                    }
                });
    }

    private void initRecyclerView() {
        List<String> dataList = initData();

        RecyclerView mainRv = findViewById(R.id.main_rv);
        RecyclerView.LayoutManager manager = new LinearLayoutManager(mActivity);
        mainRv.setLayoutManager(manager);

        RecyclerView.ItemDecoration decoration = new DividerItemDecoration(mActivity,
                DividerItemDecoration.VERTICAL);
        mainRv.addItemDecoration(decoration);

        RecyclerView.Adapter adapter = new MainAdapter(dataList, this);
        mainRv.setAdapter(adapter);
    }

    private List<String> initData() {
        mDataList = new ArrayList<>();
        Collections.addAll(mDataList, "添加数据", "更新数据", "删除数据", "查询所有",
                "数据库扩展");
        return mDataList;
    }

    @Override
    public void onClick(int pos) {
        switch (mDataList.get(pos)) {
            case "添加数据": {
                BaseDaoFactory instance = BaseDaoFactory.getInstance();
                BaseDao<Person> baseDao = instance.getBaseDao(BaseDao.class, Person.class);

                Person person = new Person(RandomUtils.getInt(1000),
                        RandomUtils.getStringByUuid(6),
                        RandomUtils.getInt(100),
                        RandomUtils.getDouble(0, 3000, 2));

                Log.d(Contants.TAG, person.toString());

                try {
                    long res = baseDao.insert(person);
                    if (res > 0) {
                        Log.d(Contants.TAG, "添加成功");
                    } else {
                        Log.d(Contants.TAG, "添加失败");
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    Log.d(Contants.TAG, "添加数据发生异常");
                }
                break;
            }

            case "更新数据": {
                // 更新数据
                Person newPerson = new Person(RandomUtils.getInt(100),
                        RandomUtils.getString(6),
                        RandomUtils.getInt(100),
                        RandomUtils.getDouble(0, 1000, 2));
                Log.d(Contants.TAG, "新数据内容 : " + newPerson.toString());

                Person wherePerson = new Person(455, "9a3a38", 23, 530.24);

                BaseDao<Person> baseDao = BaseDaoFactory.getInstance()
                        .getBaseDao(BaseDao.class, Person.class);
                try {
                    long updateRes = baseDao.update(newPerson, wherePerson);
                    if (updateRes > 0) {
                        Log.d(Contants.TAG, "更新成功");
                    } else {
                        Log.d(Contants.TAG, "更新失败");
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    Log.d(Contants.TAG, "发生异常 : " + e.getMessage());
                }
                break;
            }

            case "删除数据": {
                Person wherePerson = new Person(33, "zFG1By", 51, 726.58);
                BaseDao<Person> baseDao = BaseDaoFactory.getInstance().getBaseDao(
                        BaseDao.class, Person.class);
                try {
                    int deleteRes = baseDao.delete(wherePerson);
                    if (deleteRes > 0) {
                        Log.d(Contants.TAG, "删除成功");
                    } else {
                        Log.d(Contants.TAG, "删除失败");
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                    Log.d(Contants.TAG, "发生异常 : " + e.getMessage());
                }
                break;
            }

            case "查询所有": {
                BaseDao<Person> baseDao = BaseDaoFactory.getInstance().getBaseDao(
                        BaseDao.class, Person.class);
                try {
                    List<Person> personList = baseDao.query(new Person());
                    Log.d(Contants.TAG, personList.toString());
                } catch (IllegalAccessException | NoSuchFieldException | InstantiationException e) {
                    e.printStackTrace();
                    Log.d(Contants.TAG, "发生异常 : " + e.getMessage());
                }
                break;
            }

            case "数据库扩展": {
                PersonDao<Person> personDao = BaseDaoFactory.getInstance().getBaseDao(
                        PersonDao.class, Person.class);
                try {
                    List<Person> personList = personDao.queryColumn(new Person(), new String[]{"age"});
                    Log.d(Contants.TAG, personList.toString());
                } catch (IllegalAccessException | NoSuchFieldException | InstantiationException e) {
                    e.printStackTrace();
                    Log.d(Contants.TAG, "发生异常 : " + e.getMessage());
                }
                break;
            }

            default:
                break;
        }
    }
}
