package com.cjw.demo1;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public interface Contants {

    String TAG = "cjw";
}
