package com.cjw.demo1.bean;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public class Animal {

    private String name;
    private int age;
    private String birthday;

}
