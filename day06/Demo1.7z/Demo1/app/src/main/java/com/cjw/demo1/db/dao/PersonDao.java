package com.cjw.demo1.db.dao;

import java.util.List;

/**
 * Created by Administrator on 2018/3/11.
 */

public class PersonDao<T> extends BaseDao<T> {

    public List<T> queryColumn(T entity, String[] columnArr) throws IllegalAccessException,
            NoSuchFieldException, InstantiationException {
        return query(entity, columnArr, null, null, null);
    }
}
