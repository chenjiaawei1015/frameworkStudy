package com.cjw.demo1.db.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;

import com.cjw.demo1.Contants;
import com.cjw.demo1.db.annotation.DbField;
import com.cjw.demo1.db.annotation.DbTable;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BaseDao<T> implements IDao<T> {

    // 是否创建了表
    private boolean mIsCreateTable;

    private SQLiteDatabase mSqliteDatabase;

    // key -> 数据库字段名
    // value -> 成员变量名
    private Map<String, String> mCacheMap;

    // 表名
    private String mTableName;

    public void init(SQLiteDatabase database, Class<T> entity) {
        mSqliteDatabase = database;
        if (!database.isOpen()) {
            throw new RuntimeException("不能多次进行初始化");
        }

        if (!mIsCreateTable) {
            createTable(database, entity);
            mIsCreateTable = true;

            initCacheMap(entity);
        }
    }

    private void initCacheMap(Class<T> entity) {
        mCacheMap = new HashMap<>();
        Field[] fields = entity.getDeclaredFields();
        String fieldKey;
        String fieldName;
        for (Field itemField : fields) {
            itemField.setAccessible(true);
            fieldName = itemField.getName();

            DbField fieldAnnotation = itemField.getAnnotation(DbField.class);
            if (fieldAnnotation == null) {
                fieldKey = fieldName;
            } else {
                fieldKey = fieldAnnotation.value();
            }

            mCacheMap.put(fieldKey, fieldName);
        }
    }

    private void createTable(SQLiteDatabase database, Class<T> entity) {
        // create table if not exists tb_user(_id integer,name varchar(20),password varchar(20))

        DbTable tableAnnotation = entity.getAnnotation(DbTable.class);
        if (tableAnnotation == null) {
            mTableName = entity.getSimpleName();
        } else {
            mTableName = tableAnnotation.value();
        }

        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("create table if not exists ").append(mTableName).append("(");

        Map<String, String> fieldTypeMap = getFieldTypeMap(entity);
        Set<Map.Entry<String, String>> fieldEntriesSet = fieldTypeMap.entrySet();
        for (Map.Entry<String, String> itemEntry : fieldEntriesSet) {
            String fieldKey = itemEntry.getKey();
            String fieldValue = itemEntry.getValue();
            sqlBuilder.append(fieldKey).append(" ").append(fieldValue).append(",");
        }

        int length = sqlBuilder.length();
        if (sqlBuilder.charAt(length - 1) == ',') {
            sqlBuilder.deleteCharAt(length - 1);
        }
        sqlBuilder.append(")");

        String sql = sqlBuilder.toString();
        Log.d(Contants.TAG, "创建表 sql : " + sql);

        database.execSQL(sql);
    }

    /**
     * 获取 数据库字段名 与 数据库字段类型 的对应关系
     */
    private Map<String, String> getFieldTypeMap(Class<T> entity) {
        // key -> 数据库字段名称
        // value -> 类型名称
        Map<String, String> fieldMap = new HashMap<>();
        String fieldKey;
        String fieldType;

        Field[] fields = entity.getDeclaredFields();
        for (Field itemField : fields) {
            itemField.setAccessible(true);
            DbField fieldAnnotation = itemField.getAnnotation(DbField.class);
            if (fieldAnnotation == null) {
                fieldKey = itemField.getName();
            } else {
                fieldKey = fieldAnnotation.value();
            }

            Class<?> type = itemField.getType();
            if (type.equals(String.class)) {
                fieldType = "TEXT";
            } else if (type.equals(Integer.class)) {
                fieldType = "INTEGER";
            } else if (type.equals(Double.class)) {
                fieldType = "DOUBLE";
            } else if (type.equals(Long.class)) {
                fieldType = "Long";
            } else {
                fieldType = "BLOB";
            }

            if (!TextUtils.isEmpty(fieldKey) && !TextUtils.isEmpty(fieldType)) {
                fieldMap.put(fieldKey, fieldType);
            }
        }
        return fieldMap;
    }

    @Override
    public long insert(T entity) throws IllegalAccessException {
        // key -> 数据库字段名
        // value -> 值
        Map<String, String> fieldValueMap = generateMapForEntity(entity);
        ContentValues contentValues = getContentValues(fieldValueMap);
        return mSqliteDatabase.insert(mTableName, null, contentValues);
    }

    /**
     * 获取 ContentValues
     *
     * @param fieldValueMap key -> 数据库字段名 , value -> 值
     */
    @NonNull
    private ContentValues getContentValues(Map<String, String> fieldValueMap) {
        ContentValues contentValues = new ContentValues();
        Set<Map.Entry<String, String>> entries = fieldValueMap.entrySet();
        for (Map.Entry<String, String> itemEntries : entries) {
            String key = itemEntries.getKey();
            String value = itemEntries.getValue();
            contentValues.put(key, value);
        }
        return contentValues;
    }

    @Override
    public long update(T entity, T where) throws IllegalAccessException {
        Map<String, String> entityMap = generateMapForEntity(entity);
        ContentValues contentValues = getContentValues(entityMap);

        entityMap = generateMapForEntity(where);
        Condition condition = new Condition(entityMap);
        return mSqliteDatabase.update(mTableName, contentValues,
                condition.whereClause, condition.whereArgs);
    }

    @Override
    public int delete(T where) throws IllegalAccessException {
        Map<String, String> entityMap = generateMapForEntity(where);
        Condition condition = new Condition(entityMap);
        return mSqliteDatabase.delete(mTableName, condition.whereClause, condition.whereArgs);
    }

    @Override
    public List<T> query(T where) throws IllegalAccessException, NoSuchFieldException,
            InstantiationException {
        return query(where, null, null, null, null);
    }

    @Override
    public List<T> query(T where, String[] columns, String orderBy, Integer startIndex,
                         Integer limit)
            throws IllegalAccessException, NoSuchFieldException, InstantiationException {
        Map<String, String> whereMap = generateMapForEntity(where);
        Condition condition = new Condition(whereMap);

        String limitStr = null;
        if (startIndex != null && limit != null) {
            limitStr = startIndex + " , " + limit;
        }

        Cursor cursor = mSqliteDatabase.query(mTableName, columns, condition.whereClause,
                condition.whereArgs, null, null, orderBy, limitStr);

        List<T> dataList = new ArrayList<>();

        while (cursor.moveToNext()) {
            T data = generateData(cursor, (Class<T>) where.getClass());
            dataList.add(data);
        }
        cursor.close();
        return dataList;
    }

    private T generateData(Cursor cursor, Class<T> tClass) throws NoSuchFieldException,
            IllegalAccessException, InstantiationException {
        // key -> 数据库字段名
        // value -> 成员变量名
        Set<Map.Entry<String, String>> entrySet = mCacheMap.entrySet();
        Object instance = null;
        if (!entrySet.isEmpty()) {
            instance = tClass.newInstance();
        }
        for (Map.Entry<String, String> entry : entrySet) {
            String fieldName = entry.getKey();
            String paramsName = entry.getValue();

            int columnIndex = cursor.getColumnIndex(fieldName);
            if (columnIndex < 0) {
                continue;
            }

            Field field = tClass.getDeclaredField(paramsName);
            field.setAccessible(true);
            Class<?> fieldType = field.getType();
            if (fieldType.equals(String.class)) {
                String value = cursor.getString(columnIndex);
                field.set(instance, value);
            } else if (fieldType.equals(Integer.class)) {
                Integer value = cursor.getInt(columnIndex);
                field.set(instance, value);
            } else if (fieldType.equals(Long.class)) {
                long value = cursor.getLong(columnIndex);
                field.set(instance, value);
            } else if (fieldType.equals(Double.class)) {
                Double value = cursor.getDouble(columnIndex);
                field.set(instance, value);
            }
        }
        return (T) instance;
    }

    private class Condition {
        String whereClause;
        String[] whereArgs;

        Condition(Map<String, String> map) {
            if (map != null) {
                StringBuilder clauseBuild = new StringBuilder();
                List<String> argsList = new ArrayList<>();

                clauseBuild.append("1==1 ");

                for (Map.Entry<String, String> entry : map.entrySet()) {
                    String key = entry.getKey();
                    String value = entry.getValue();
                    if (TextUtils.isEmpty(value)) {
                        continue;
                    }
                    clauseBuild.append("AND ").append(key).append("=? ");
                    argsList.add(value);
                }

                whereClause = clauseBuild.toString();
                whereArgs = argsList.toArray(new String[argsList.size()]);
            }
        }
    }

    private Map<String, String> generateMapForEntity(T entity) throws IllegalAccessException {
        if (entity == null) {
            return null;
        }

        // key -> 数据库字段名
        // value -> 值
        Map<String, String> fieldValueMap = new HashMap<>();

        Field[] fields = entity.getClass().getDeclaredFields();
        String key;
        String value;
        for (Field itemField : fields) {
            itemField.setAccessible(true);

            DbField dbFieldAnnotation = itemField.getAnnotation(DbField.class);
            if (dbFieldAnnotation == null) {
                key = itemField.getName();
            } else {
                key = dbFieldAnnotation.value();
            }
            Object fieldValue = itemField.get(entity);
            if (fieldValue == null) {
                value = "";
            } else {
                value = fieldValue.toString();
            }
            fieldValueMap.put(key, value);
        }

        return fieldValueMap;
    }
}
