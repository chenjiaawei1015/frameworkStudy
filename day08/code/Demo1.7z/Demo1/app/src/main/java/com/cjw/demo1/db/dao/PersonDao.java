package com.cjw.demo1.db.dao;

import java.util.List;


public class PersonDao<T> extends BaseDao<T> {

    public List<T> queryColumn(T entity, String[] columnArr) throws IllegalAccessException,
            NoSuchFieldException, InstantiationException {
        return query(entity, columnArr, null, null, null);
    }
}
