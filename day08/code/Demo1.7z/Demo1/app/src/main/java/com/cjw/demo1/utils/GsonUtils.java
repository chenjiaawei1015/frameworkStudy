package com.cjw.demo1.utils;

import com.google.gson.Gson;

/**
 * Created by Administrator on 2018/3/15.
 */

public class GsonUtils {

    public static String toJson(Object obj) {
        Gson gson = new Gson();
        return gson.toJson(obj);
    }
}
