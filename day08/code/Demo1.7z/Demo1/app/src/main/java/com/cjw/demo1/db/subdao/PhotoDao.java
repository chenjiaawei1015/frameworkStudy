package com.cjw.demo1.db.subdao;

import com.cjw.demo1.bean.Photo;
import com.cjw.demo1.db.dao.BaseDao;

/**
 * Created by Administrator on 2018/3/13.
 */

public class PhotoDao extends BaseDao<Photo> {
}
