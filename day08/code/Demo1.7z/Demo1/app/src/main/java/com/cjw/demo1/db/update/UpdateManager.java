package com.cjw.demo1.db.update;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import com.cjw.demo1.Contants;
import com.cjw.demo1.bean.Person;
import com.cjw.demo1.db.dao.BaseDaoFactory;
import com.cjw.demo1.db.dao.PersonDao;
import com.cjw.demo1.db.update.xml.CreateDb;
import com.cjw.demo1.db.update.xml.CreateVersion;
import com.cjw.demo1.db.update.xml.UpdateDb;
import com.cjw.demo1.db.update.xml.UpdateDbXml;
import com.cjw.demo1.db.update.xml.UpdateStep;
import com.cjw.demo1.utils.GsonUtils;

import org.w3c.dom.Document;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * 升级管理
 * Created by Administrator on 2018/3/15.
 */

public class UpdateManager {

    private static final String PACKAGE_NAME = "com.cjw.demo1";
    private static final String DATABASE_NAME = "cjw.db";

    private static final String CURRENT_VERSION = "V001";
    private static final String NEW_VERSION = "V002";

    /**
     * 升级表结构
     */
    public void updateTable(Context context) {
        Log.d(Contants.TAG, "开始升级表结构");
        PersonDao personDao = getPersonDao();
        try {
            List<Person> list = personDao.query(new Person());
            Log.d(Contants.TAG, "所有用户的个数 : " + list.size());

            UpdateDbXml dbXml = readAssetsFile(context);
            Log.d(Contants.TAG, "xml解析 : " + GsonUtils.toJson(dbXml));

            // 获取所有版本
            List<CreateVersion> createVersionList = dbXml.getCreateVersions();
            CreateVersion newCreateVersion = queryNewCreateVersion(createVersionList);
            List<CreateDb> createDbs = newCreateVersion.getCreateDbs();

            List<UpdateStep> updateStepList = dbXml.getUpdateSteps();
            UpdateStep updateStep = queryVersion(updateStepList);
            Log.d(Contants.TAG, "updateStep : " + GsonUtils.toJson(updateStep));
            List<UpdateDb> updateDbs = updateStep.getUpdateDbs();

            for (Person person : list) {
                String id = person.getId();
                SQLiteDatabase database = getSQLiteDatabase(id);

                for (UpdateDb itemUpdateDb : updateDbs) {
                    String dbName = itemUpdateDb.getDbName();

                    // 寻找到 createDb 标签下 name 属性值与 dbName 相同的节点
                    CreateDb createDb = findCreateDbByName(createDbs, dbName);
                    Log.d(Contants.TAG, dbName + "对应的 createDb : "
                            + GsonUtils.toJson(createDb));

                    if (createDb != null) {
                        List<String> sqlCreates = createDb.getSqlCreates();
                        List<String> sqlBefores = itemUpdateDb.getSqlBefores();
                        List<String> sqlAfters = itemUpdateDb.getSqlAfters();

                        List<String> sqlList = new ArrayList<>();
                        sqlList.addAll(sqlBefores);
                        sqlList.addAll(sqlCreates);
                        sqlList.addAll(sqlAfters);

                        database.beginTransaction();

                        for (String sql : sqlList) {
                            Log.d(Contants.TAG, "用户id : " + id + " , 执行 sql : " + sql);
                            database.execSQL(sql);
                        }
                        database.setTransactionSuccessful();
                        database.endTransaction();
                    }
                }

                database.close();
            }

            Log.d(Contants.TAG, "表升级结束");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private CreateDb findCreateDbByName(List<CreateDb> createDbList, String dbName) {
        for (CreateDb createDb : createDbList) {
            if (TextUtils.equals(createDb.getName(), dbName)) {
                return createDb;
            }
        }
        return null;
    }

    /**
     * 根据新旧版本获取对应的 updateStep
     */
    private UpdateStep queryVersion(List<UpdateStep> updateStepList) {
        for (UpdateStep step : updateStepList) {
            String versionFrom = step.getVersionFrom();
            String versionTo = step.getVersionTo();

            if (TextUtils.equals(versionFrom, CURRENT_VERSION)
                    && TextUtils.equals(versionTo, NEW_VERSION)) {
                return step;
            }
        }
        return null;
    }

    /**
     * 检测当前的表结构
     */
    public void checkCurrentTable(Context context) {
        Log.d(Contants.TAG, "检测当前的表结构");
        PersonDao personDao = getPersonDao();
        try {
            List<Person> list = personDao.query(new Person());
            Log.d(Contants.TAG, "所有用户的个数 : " + list.size());

            UpdateDbXml dbXml = readAssetsFile(context);
            Log.d(Contants.TAG, "xml解析 : " + GsonUtils.toJson(dbXml));

            // 获取所有版本
            List<CreateVersion> createVersionList = dbXml.getCreateVersions();
            CreateVersion newCreateVersion = queryNewCreateVersion(createVersionList);
            Log.d(Contants.TAG, "最新版本 : " + GsonUtils.toJson(newCreateVersion));

            if (newCreateVersion != null) {
                List<CreateDb> createDbList = newCreateVersion.getCreateDbs();

                for (Person itemPerson : list) {
                    String id = itemPerson.getId();
                    SQLiteDatabase database = getSQLiteDatabase(id);
                    for (CreateDb itemDb : createDbList) {
                        List<String> sqlCreateList = itemDb.getSqlCreates();
                        for (String sql : sqlCreateList) {
                            Log.d(Contants.TAG, "用户 : " + id + " , 表检测 : " + sql);
                            database.execSQL(sql);
                        }
                    }
                    database.close();
                }
            }

            Log.d(Contants.TAG, "表检查结束");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private PersonDao getPersonDao() {
        BaseDaoFactory instance = BaseDaoFactory.getInstance();
        return instance.getBaseDao(PersonDao.class, Person.class);
    }

    /**
     * 根据用户的id获取对应的 database
     */
    public SQLiteDatabase getSQLiteDatabase(String id) {
        String dir = Environment.getExternalStorageDirectory() + File.separator + PACKAGE_NAME +
                File.separator + id;
        File dirFile = new File(dir);
        if (!dirFile.exists()) {
            dirFile.mkdirs();
        }

        File dbFile = new File(dirFile, DATABASE_NAME);
        return SQLiteDatabase.openOrCreateDatabase(dbFile, null);
    }

    /**
     * 获取最新的 createVersion
     */
    private CreateVersion queryNewCreateVersion(List<CreateVersion> createVersionList) {
        for (CreateVersion version : createVersionList) {
            String versionName = version.getVersion();
            if (TextUtils.equals(versionName, NEW_VERSION)) {
                return version;
            }
        }
        return null;
    }

    /**
     * 从 assets 目录中读取 updateXml.xml 的内容 , 并解析为 UpdateDbXml 对象
     */
    private UpdateDbXml readAssetsFile(Context context) throws Exception {
        InputStream xmlIn = context.getAssets().open("updateXml.xml");

        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = documentBuilder.parse(xmlIn);
        return new UpdateDbXml(document);
    }
}
