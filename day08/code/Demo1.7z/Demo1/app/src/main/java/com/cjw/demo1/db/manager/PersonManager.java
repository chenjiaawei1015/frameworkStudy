package com.cjw.demo1.db.manager;

import android.text.TextUtils;
import android.util.Log;

import com.cjw.demo1.Contants;
import com.cjw.demo1.bean.Person;
import com.cjw.demo1.db.dao.BaseDaoFactory;
import com.cjw.demo1.db.dao.PersonDao;

import java.util.List;

/**
 * Person 管理类
 * Created by Administrator on 2018/3/12.
 */

public class PersonManager {

    public static final int STATUS_NOT_LOGIN = 0;
    public static final int STATUS_IS_LOGIN = 1;

    private static final PersonManager sInstance = new PersonManager();

    /**
     * 当前的登录用户
     */
    private Person mCurrentLoginPerson;

    public static PersonManager getInstance() {
        return sInstance;
    }

    public void changePerson(Person person) throws IllegalAccessException, NoSuchFieldException,
            InstantiationException {
        BaseDaoFactory instance = BaseDaoFactory.getInstance();
        PersonDao baseDao = instance.getBaseDao(PersonDao.class, Person.class);
        List<Person> personList = baseDao.query(new Person());

        boolean isFindPerson = false;

        for (Person itemPerson : personList) {
            int itemStatus = itemPerson.getStatus();
            String itemId = itemPerson.getId();
            if (TextUtils.equals(itemId, person.getId())) {
                isFindPerson = true;
                if (itemStatus != STATUS_IS_LOGIN) {
                    itemPerson.setStatus(STATUS_IS_LOGIN);
                    baseDao.update(itemPerson, new Person(itemId));
                    mCurrentLoginPerson = itemPerson;
                    Log.d(Contants.TAG, "用户 : " + itemId + " 登录成功");
                }
            } else {
                if (itemStatus != STATUS_NOT_LOGIN) {
                    itemPerson.setStatus(STATUS_NOT_LOGIN);
                    baseDao.update(itemPerson, new Person(itemId));
                    Log.d(Contants.TAG, "用户 : " + itemId + " 退出登录");
                }
            }
        }

        if (!isFindPerson) {
            person.setStatus(STATUS_IS_LOGIN);
            baseDao.insert(person);
            mCurrentLoginPerson = person;
            Log.d(Contants.TAG, "用户 : " + person.getId() + " 登录成功");
        }
    }

    /**
     * 获取当前的登录用户
     */
    public Person getCurrentLoginPerson() {
        return mCurrentLoginPerson;
    }
}
