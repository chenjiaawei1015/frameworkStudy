package com.cjw.demo1.db.dao;

import java.util.List;

public interface IDao<T> {

    long insert(T entity) throws IllegalAccessException;

    long update(T entity, T where) throws IllegalAccessException;

    int delete(T where) throws IllegalAccessException;

    List<T> query(T where) throws IllegalAccessException, NoSuchFieldException,
            InstantiationException;

    List<T> query(T where, String[] columns, String orderBy, Integer startIndex, Integer limit)
            throws IllegalAccessException, NoSuchFieldException, InstantiationException;
}
