package com.cjw.demo1.db.dao;

import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 获取 BaseDao 的工厂类
 * Created by chenjiawei on 2018/3/8.
 */

public class BaseDaoFactory {

    // 包名
    protected static final String PACKAGE_NAME = "com.cjw.demo1";
    protected static final String DATABASE_NAME = "cjw.db";

    private static BaseDaoFactory sBaseDaoFactoryInstance = new BaseDaoFactory();

    private SQLiteDatabase mSqLiteDatabase;

    protected Map<String, BaseDao> mDaoCacheMap =
            Collections.synchronizedMap(new HashMap<String, BaseDao>());

    protected BaseDaoFactory() {
        createDataBase();
    }

    public static BaseDaoFactory getInstance() {
        return sBaseDaoFactoryInstance;
    }

    protected String getDaoCacheKey(Class dao) {
        return this.getClass().getSimpleName() + dao.getSimpleName();
    }

    public <T, M extends BaseDao<T>> M getBaseDao(Class<M> dao, Class<T> entity) {
        if (entity == null) {
            return null;
        }

        String daoCacheKey = getDaoCacheKey(dao);
        if (mDaoCacheMap.containsKey(daoCacheKey)) {
            return (M) mDaoCacheMap.get(daoCacheKey);
        }

        try {
            M baseDao = dao.newInstance();
            SQLiteDatabase database = getSqLiteDatabase();
            baseDao.init(database, entity);
            return baseDao;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private void createDataBase() {
        File dirFile = new File(Environment.getExternalStorageDirectory(), PACKAGE_NAME);
        if (!dirFile.exists()) {
            boolean isMkDirsSuccess = dirFile.mkdirs();
            if (!isMkDirsSuccess) {
                throw new RuntimeException("创建数据库时,文件目录无法进行创建");
            }
        }
        File dbFile = new File(dirFile, DATABASE_NAME);
        mSqLiteDatabase = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
    }

    protected SQLiteDatabase getSqLiteDatabase() {
        return mSqLiteDatabase;
    }
}
