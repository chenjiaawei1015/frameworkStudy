package com.cjw.demo1.db.subdao;

import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import com.cjw.demo1.bean.Person;
import com.cjw.demo1.db.dao.BaseDao;
import com.cjw.demo1.db.dao.BaseDaoFactory;
import com.cjw.demo1.db.manager.PersonManager;

import java.io.File;

public class SubDaoFactory extends BaseDaoFactory {

    private static SubDaoFactory sSubDaoFactory = new SubDaoFactory();

    protected SQLiteDatabase mSubSqliteDatabase;

    private SubDaoFactory() {
    }

    public static SubDaoFactory getSubDaoInstance() {
        return sSubDaoFactory;
    }

    private void createSubDaoDataBase() {
        PersonManager personManager = PersonManager.getInstance();
        Person currentLoginPerson = personManager.getCurrentLoginPerson();

        if (currentLoginPerson == null) {
            throw new RuntimeException("当前用户没用进行登录");
        }

        String dir = Environment.getExternalStorageDirectory() + File.separator + PACKAGE_NAME +
                File.separator + currentLoginPerson.getId();
        File dirFile = new File(dir);

        if (!dirFile.exists()) {
            dirFile.mkdirs();
        }

        File dbFile = new File(dirFile, DATABASE_NAME);
        mSubSqliteDatabase = SQLiteDatabase.openOrCreateDatabase(dbFile, null);
    }

    public <T, M extends BaseDao<T>> M getBaseDao(Class<M> dao, Class<T> entity) {
        if (entity == null) {
            return null;
        }

        String daoCacheKey = getDaoCacheKey(dao);
        if (mDaoCacheMap.containsKey(daoCacheKey)) {
            return (M) mDaoCacheMap.get(daoCacheKey);
        }

        createSubDaoDataBase();

        try {
            M baseDao = dao.newInstance();
            SQLiteDatabase database = getSqLiteDatabase();
            baseDao.init(database, entity);
            return baseDao;
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected SQLiteDatabase getSqLiteDatabase() {
        return mSubSqliteDatabase;
    }
}
