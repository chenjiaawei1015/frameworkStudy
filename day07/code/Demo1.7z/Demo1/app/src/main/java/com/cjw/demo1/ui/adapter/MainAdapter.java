package com.cjw.demo1.ui.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by chenjiawei on 2018/3/8.
 */

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.MainHolder> {

    private List<String> mDataList;
    private OnItemClickListener mItemClickListener;

    public MainAdapter(List<String> dataList, OnItemClickListener itemClickListener) {
        mDataList = dataList;
        mItemClickListener = itemClickListener;
    }

    @Override
    public MainHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(android.R.layout.simple_list_item_1, parent, false);
        return new MainHolder(view);
    }

    @Override
    public void onBindViewHolder(MainHolder holder, int position) {
        String data = mDataList.get(position);
        ((TextView) holder.itemView).setText(data);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onClick(int pos);
    }

    class MainHolder extends RecyclerView.ViewHolder {

        MainHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getLayoutPosition();
                    mItemClickListener.onClick(pos);
                }
            });
        }
    }
}
