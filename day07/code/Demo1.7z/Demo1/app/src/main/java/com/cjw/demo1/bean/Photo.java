package com.cjw.demo1.bean;

import com.cjw.demo1.db.annotation.DbField;
import com.cjw.demo1.db.annotation.DbTable;

/**
 * 图片信息
 * Created by Administrator on 2018/3/12.
 */
@DbTable("tb_photo")
public class Photo {

    @DbField("name")
    private String photoName;

    @DbField("path")
    private String photoPath;

    public String getPhotoName() {
        return photoName;
    }

    public void setPhotoName(String photoName) {
        this.photoName = photoName;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    @Override
    public String toString() {
        return "Photo{" +
                "photoName='" + photoName + '\'' +
                ", photoPath='" + photoPath + '\'' +
                '}';
    }
}
