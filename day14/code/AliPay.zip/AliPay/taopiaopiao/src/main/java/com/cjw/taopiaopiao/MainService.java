package com.cjw.taopiaopiao;

import android.content.Intent;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import com.cjw.pluginstand.LogUtils;
import java.util.Locale;

public class MainService extends BaseService {

  @Override public void onCreate() {
    super.onCreate();

    new Thread(new Runnable() {
      @Override public void run() {
        for (int i = 0; i < 300; i++) {
          SystemClock.sleep(1000);

          String msg = String.format(Locale.CHINA, "插件服务 : %d", i);
          LogUtils.debug(msg);
        }
      }
    }).start();
  }
}
