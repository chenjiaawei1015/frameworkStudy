package com.cjw.pluginstand;

import android.util.Log;

public class LogUtils {

  private static final String TAG = "cjw";

  public static void debug(String message) {
    Log.d(TAG, message);
  }
}
