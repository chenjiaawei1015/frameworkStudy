package com.cjw.alipay;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import com.cjw.pluginstand.LogUtils;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class PluginManager {

  private static PluginManager sPluginManager = new PluginManager();

  private Resources mPluginResource;
  private PackageInfo mPackageInfo;
  private DexClassLoader mDexClassLoader;

  private PluginManager() {
  }

  public static PluginManager getInstance() {
    return sPluginManager;
  }

  public void loadPlugin(Context context, String path) {
    try {
      Constructor<AssetManager> constructor = AssetManager.class.getDeclaredConstructor();
      constructor.setAccessible(true);
      AssetManager assetManager = constructor.newInstance();

      Method addAssetPathMethod =
          AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
      addAssetPathMethod.setAccessible(true);
      addAssetPathMethod.invoke(assetManager, path);

      Context applicationContext = context.getApplicationContext();
      Resources resources = applicationContext.getResources();
      mPluginResource = new Resources(assetManager, resources.getDisplayMetrics(),
          resources.getConfiguration());

      PackageManager packageManager = applicationContext.getPackageManager();
      mPackageInfo = packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES);

      File optFile = new File(context.getCacheDir(), "opt");
      if (!optFile.exists()) {
        optFile.mkdirs();
      }
      mDexClassLoader = new DexClassLoader(path, optFile.getAbsolutePath(), null,
          context.getClassLoader());

      LogUtils.debug("加载成功");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Resources getPluginResource() {
    return mPluginResource;
  }

  public PackageInfo getPackageInfo() {
    return mPackageInfo;
  }

  public DexClassLoader getDexClassLoader() {
    return mDexClassLoader;
  }
}
