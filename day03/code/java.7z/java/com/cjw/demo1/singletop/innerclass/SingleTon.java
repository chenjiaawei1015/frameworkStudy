package com.cjw.demo1.singletop.innerclass;

/**
 * Created by Administrator on 2018/3/3.
 */

public class SingleTon {

    // 缺点:
    // 1.不能传递参数
    // 2.通过反射可以创建对象

    private SingleTon() {
    }

    public static class SingleTonHolder {
        private static SingleTon sInstance = new SingleTon();

        public static SingleTon getInstance() {
            return sInstance;
        }
    }

}
