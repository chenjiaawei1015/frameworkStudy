package com.cjw.demo1.singletop.enumerate;

/**
 * Created by Administrator on 2018/3/3.
 */

public enum SingleTon {

    // 缺点:
    // 1.效率不高

    sInstance;

    public void showName() {
        System.out.println("SingleTon name");
    }
}
