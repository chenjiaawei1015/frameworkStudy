package com.cjw.demo1.singletop.notlazy;

/**
 * Created by Administrator on 2018/3/3.
 */

public class SingleTon {

    // 缺点:
    // 1.类加载的时候会创建对象
    // 2.不能传递参数
    // 3.通过反射可以创建对象

    private static SingleTon sInstance = new SingleTon();

    private SingleTon() {
    }

    public static SingleTon getInstance() {
        return sInstance;
    }

}
