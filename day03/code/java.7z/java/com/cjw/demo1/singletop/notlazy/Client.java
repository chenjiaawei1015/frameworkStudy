package com.cjw.demo1.singletop.notlazy;

import org.junit.Test;

import java.lang.reflect.Constructor;

/**
 * Created by Administrator on 2018/3/3.
 */

public class Client {

    @Test
    public void testSingleTon() {
        SingleTon instance1 = SingleTon.getInstance();
        System.out.println(instance1);

        SingleTon instance2 = SingleTon.getInstance();
        System.out.println(instance2);

        try {
            String className = "com.cjw.demo1.singletop.notlazy.SingleTon";
            Class<?> instanceClazz = Class.forName(className);
            Constructor<?> constructor = instanceClazz.getDeclaredConstructor();
            constructor.setAccessible(true);
            SingleTon instance3 = (SingleTon) constructor.newInstance();
            System.out.println(instance3);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
