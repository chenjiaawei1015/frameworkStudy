package com.cjw.demo1.singletop.lazy;

/**
 * Created by Administrator on 2018/3/3.
 */

public class SingleTon {

    // 缺点:
    // 1.效率不高
    // 2.通过反射可以创建对象

    private static SingleTon sInstance;

    private SingleTon() {
    }

    public synchronized static SingleTon getInstance() {
        if (sInstance == null) {
            sInstance = new SingleTon();
        }
        return sInstance;
    }

}
