package com.cjw.demo1.singletop.doublecheck;

/**
 * Created by Administrator on 2018/3/3.
 */

public class SingleTon {

    // 缺点:
    // 1.通过反射可以创建对象
    // 2.volatile会使效率变慢

    private volatile static SingleTon sInstance;

    private SingleTon() {
    }

    public static SingleTon getInstance() {
        if (sInstance == null) {
            synchronized (SingleTon.class) {
                if (sInstance == null) {
                    sInstance = new SingleTon();
                }
            }
        }
        return sInstance;
    }

}
