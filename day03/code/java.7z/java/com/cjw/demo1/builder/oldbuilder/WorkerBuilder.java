package com.cjw.demo1.builder.oldbuilder;

/**
 * Created by Administrator on 2018/3/3.
 */

public class WorkerBuilder implements IBuilder {

    private RoomParams mRoomParams = new RoomParams();

    @Override
    public void buildFloor(String name) {
        mRoomParams.setFloor(name);
    }

    @Override
    public void buildWindow(String name) {
        mRoomParams.setWindow(name);
    }

    @Override
    public Room createRoom() {
        Room room = new Room();
        room.apply(mRoomParams);
        return room;
    }
}
