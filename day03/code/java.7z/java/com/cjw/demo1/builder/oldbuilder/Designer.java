package com.cjw.demo1.builder.oldbuilder;

/**
 * Created by Administrator on 2018/3/3.
 */

public class Designer {

    private IBuilder mBuilder;

    public Designer() {
        mBuilder = new WorkerBuilder();
    }

    public Room createRoom(String floorName, String windowName) {
        mBuilder.buildFloor(floorName);
        mBuilder.buildWindow(windowName);
        return mBuilder.createRoom();
    }
}
