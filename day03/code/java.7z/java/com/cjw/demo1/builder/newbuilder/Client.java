package com.cjw.demo1.builder.newbuilder;

import org.junit.Test;

/**
 * Created by Administrator on 2018/3/3.
 */

public class Client {

    @Test
    public void testBuilder() {
        WorkerBuilder workerBuilder = new WorkerBuilder();
        Room room = workerBuilder.buildFloor("中式")
                .buildWindow("法式").buildWindow("欧式").create();
        System.out.println(room);
    }
}
