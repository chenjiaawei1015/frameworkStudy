package com.cjw.demo1.builder.oldbuilder;

/**
 * Created by Administrator on 2018/3/3.
 */

public class Room {

    private String floor;
    private String window;

    public void apply(RoomParams roomParams) {
        floor = roomParams.getFloor();
        window = roomParams.getWindow();
    }

    @Override
    public String toString() {
        return "Room{" +
                "floor='" + floor + '\'' +
                ", window='" + window + '\'' +
                '}';
    }
}
