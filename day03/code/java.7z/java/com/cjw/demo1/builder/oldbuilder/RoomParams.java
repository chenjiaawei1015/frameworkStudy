package com.cjw.demo1.builder.oldbuilder;

/**
 * Created by Administrator on 2018/3/3.
 */

public class RoomParams {

    private String floor;
    private String window;

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getWindow() {
        return window;
    }

    public void setWindow(String window) {
        this.window = window;
    }
}
