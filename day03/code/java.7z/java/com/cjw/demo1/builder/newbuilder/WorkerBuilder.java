package com.cjw.demo1.builder.newbuilder;

/**
 * Created by Administrator on 2018/3/3.
 */

public class WorkerBuilder {

    private RoomParams mRoomParams = new RoomParams();

    public WorkerBuilder buildWindow(String name) {
        mRoomParams.setWindow(name);
        return this;
    }

    public WorkerBuilder buildFloor(String name) {
        mRoomParams.setFloor(name);
        return this;
    }

    public Room create() {
        Room room = new Room();
        room.apply(mRoomParams);
        return room;
    }

}
