package com.cjw.demo1.builder.oldbuilder;

/**
 * Created by Administrator on 2018/3/3.
 */

public interface IBuilder {

    void buildFloor(String name);

    void buildWindow(String name);

    Room createRoom();

}
