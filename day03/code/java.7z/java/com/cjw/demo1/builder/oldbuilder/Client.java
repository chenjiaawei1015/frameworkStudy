package com.cjw.demo1.builder.oldbuilder;

import org.junit.Test;

/**
 * Created by Administrator on 2018/3/3.
 */

public class Client {

    @Test
    public void testBuilder1() {
        Designer designer = new Designer();

        Room room = designer.createRoom("中式", "欧式");
        System.out.println(room);
    }

}
