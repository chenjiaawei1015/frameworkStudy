package com.cjw.skincore;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.view.ViewCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 用于筛选View对象
 * Created by Administrator on 2018/3/17.
 */

public class SkinAttribute {

    private static final String[] ATTRIBUTE_ARR = {
            "background",
            "src",
            "textColor",
            "drawableLeft",
            "drawableTop",
            "drawableRight",
            "drawableBottom",
    };

    private Map<View, List<SkinPair>> mSkinPairMap = new HashMap<>();

    public void load(View view, AttributeSet attrs) {
        int attributeCount = attrs.getAttributeCount();
        List<SkinPair> skinPairList = new ArrayList<>();

        for (int i = 0; i < attributeCount; i++) {
            String attributeName = attrs.getAttributeName(i);

            boolean isContain = isContainAttribute(attributeName);
            if (isContain) {
                String attributeValue = attrs.getAttributeValue(i);
                // 获取id的值
                int attributeId = mapAttributeValue(view, attributeValue);

                if (attributeId != 0) {
                    SkinPair pair = new SkinPair(attributeName, attributeId);
                    skinPairList.add(pair);
                }
            }
        }

        if (!skinPairList.isEmpty()) {
            mSkinPairMap.put(view, skinPairList);

            // 更换皮肤
            updateSkin(view.getContext());
        }
    }

    private int mapAttributeValue(View view, String attributeValue) {
        int attributeId = 0;

        if (attributeValue.startsWith("#")) {
            return attributeId;
        }

        if (attributeValue.startsWith("?")) {
            // attr Id
            int attrId = Integer.parseInt(attributeValue.substring(1));
            // 获得 主题 style 中的 对应 attr 的资源id值
            attributeId = SkinThemeUtils.getResId(view.getContext(), new int[]{attrId})[0];
            return attributeId;
        }

        attributeId = Integer.parseInt(attributeValue.substring(1));
        return attributeId;
    }

    private boolean isContainAttribute(String attributeName) {
        for (String name : ATTRIBUTE_ARR) {
            if (TextUtils.equals(attributeName, name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 更换皮肤
     */
    public void updateSkin(Context context) {
        SkinResource skinResource = SkinResource.getInstance(context);

        Set<Map.Entry<View, List<SkinPair>>> entries = mSkinPairMap.entrySet();
        for (Map.Entry<View, List<SkinPair>> entry : entries) {
            View view = entry.getKey();
            List<SkinPair> skinPairList = entry.getValue();

            Drawable left = null, top = null, right = null, bottom = null;

            for (SkinPair pair : skinPairList) {
                switch (pair.attributeName) {
                    case "background":
                        Object background = skinResource.getBackground(pair.attributeId);
                        // Color
                        if (background instanceof Integer) {
                            view.setBackgroundColor((Integer) background);
                        } else {
                            ViewCompat.setBackground(view, (Drawable) background);
                        }
                        break;

                    case "src":
                        background = skinResource.getBackground(pair.attributeId);
                        if (background instanceof Integer) {
                            ((ImageView) view).setImageDrawable(
                                    new ColorDrawable((Integer) background));
                        } else {
                            ((ImageView) view).setImageDrawable((Drawable) background);
                        }
                        break;

                    case "textColor":
                        ((TextView) view).setTextColor(
                                skinResource.getColorStateList(pair.attributeId));
                        break;

                    case "drawableLeft":
                        left = skinResource.getDrawable(pair.attributeId);
                        break;
                    case "drawableTop":
                        top = skinResource.getDrawable(pair.attributeId);
                        break;
                    case "drawableRight":
                        right = skinResource.getDrawable(pair.attributeId);
                        break;
                    case "drawableBottom":
                        bottom = skinResource.getDrawable(pair.attributeId);
                        break;

                    default:
                        break;
                }
            }

            if (left != null || top != null || right != null || bottom != null) {
                ((TextView) view).setCompoundDrawablesWithIntrinsicBounds(left, top, right, bottom);
            }
        }
    }

    private static class SkinPair {
        String attributeName;
        int attributeId;

        SkinPair(String attributeName, int attributeId) {
            this.attributeName = attributeName;
            this.attributeId = attributeId;
        }
    }
}
