package com.cjw.skincore;


public interface Contants {

    String TAG = "cjw";
}
