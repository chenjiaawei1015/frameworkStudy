package com.cjw.skincore;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * Activity 生命周期回调
 */
public class SkinLifecycleCallback implements Application.ActivityLifecycleCallbacks {

    private Map<String, SkinFactory2> mSkinObserverMap = new HashMap<>();

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        LayoutInflater inflater = LayoutInflater.from(activity);

        try {
            // 先将 mFactorySet 设置为 false
            // 因为在调用 setFactory2 方法有一个限制,如果 mFactorySet 为 true ,会抛出异常
            Field factorySetField = LayoutInflater.class.getDeclaredField("mFactorySet");
            factorySetField.setAccessible(true);
            factorySetField.set(inflater, false);

            // 通过设置 factory2 , 使创建 View 对象的操作交给 factory2
            SkinFactory2 factory2 = new SkinFactory2(activity.getApplicationContext());
            inflater.setFactory2(factory2);

            String activityName = activity.getClass().getName();
            Log.d(Contants.TAG, activityName + " 设置 setFactory2 成功 ");

            // 注册监听
            SkinManager skinManager = SkinManager.getInstance();
            skinManager.addObserver(factory2);
            mSkinObserverMap.put(activityName, factory2);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityStarted(Activity activity) {

    }

    @Override
    public void onActivityResumed(Activity activity) {

    }

    @Override
    public void onActivityPaused(Activity activity) {

    }

    @Override
    public void onActivityStopped(Activity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        // 取消监听
        String activityName = activity.getClass().getName();
        SkinFactory2 factory2 = mSkinObserverMap.get(activityName);
        if (factory2 != null) {
            SkinManager manager = SkinManager.getInstance();
            manager.deleteObserver(factory2);
        }
    }
}
