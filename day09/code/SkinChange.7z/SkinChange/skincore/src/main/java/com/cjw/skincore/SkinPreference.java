package com.cjw.skincore;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

public class SkinPreference {

    private static final String PREFERENCE_NAME = "skin_preference";
    private static final String KEY_SKIN_RESOURCE_PATH = "key_skin_resource_path";

    private static SkinPreference sSkinPreference;
    private Application mApplication;

    private SkinPreference(Application application) {
        mApplication = application;
    }

    public static SkinPreference getInstance(Application application) {
        if (sSkinPreference == null) {
            synchronized (SkinPreference.class) {
                if (sSkinPreference == null) {
                    sSkinPreference = new SkinPreference(application);
                }
            }
        }
        return sSkinPreference;
    }

    public void setSkinResourcePath(String path) {
        SharedPreferences preferences =
                mApplication.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_SKIN_RESOURCE_PATH, path);
        editor.apply();
    }

    public String getSkinResourcePath() {
        SharedPreferences preferences =
                mApplication.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
        return preferences.getString(KEY_SKIN_RESOURCE_PATH, "");
    }
}
