package com.cjw.skincore;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;

public class SkinResource {

    private static SkinResource sSkinResource;

    /**
     * 是否通过系统默认的 Resource 进行加载
     */
    private boolean mIsLoadDefaultRes;

    /**
     * 皮肤包的 Resource
     */
    private Resources mSkinResource;

    private Resources mAppResource;

    private String mSkinPkgName;

    private SkinResource(Context context) {
        mAppResource = context.getApplicationContext().getResources();
    }

    public static SkinResource getInstance(Context context) {
        if (sSkinResource == null) {
            synchronized (SkinResource.class) {
                if (sSkinResource == null) {
                    sSkinResource = new SkinResource(context);
                }
            }
        }
        return sSkinResource;
    }

    /**
     * 重置
     */
    public void reset() {
        mIsLoadDefaultRes = true;
        mSkinResource = null;
        mSkinPkgName = null;
    }

    /**
     * 应用皮肤包
     */
    public void applySkin(Resources resources, String pkgName) {
        mSkinResource = resources;
        mSkinPkgName = pkgName;
        // 是否使用默认皮肤
        mIsLoadDefaultRes = TextUtils.isEmpty(pkgName) || resources == null;
    }

    public int getIdentifier(int resId) {
        if (mIsLoadDefaultRes) {
            return resId;
        }
        // 在皮肤包中不一定就是 当前程序的 id
        // 获取对应id 在当前的名称 colorPrimary
        // R.drawable.ic_launcher
        String resName = mAppResource.getResourceEntryName(resId); // ic_launcher
        String resType = mAppResource.getResourceTypeName(resId); // drawable
        return mSkinResource.getIdentifier(resName, resType, mSkinPkgName);
    }

    public int getColor(int resId) {
        if (mIsLoadDefaultRes) {
            return mAppResource.getColor(resId);
        }
        int skinId = getIdentifier(resId);
        if (skinId == 0) {
            return mAppResource.getColor(resId);
        }
        return mSkinResource.getColor(skinId);
    }

    public ColorStateList getColorStateList(int resId) {
        if (mIsLoadDefaultRes) {
            return mAppResource.getColorStateList(resId);
        }
        int skinId = getIdentifier(resId);
        if (skinId == 0) {
            return mAppResource.getColorStateList(resId);
        }
        return mSkinResource.getColorStateList(skinId);
    }

    public Drawable getDrawable(int resId) {
        //如果有皮肤  isDefaultSkin false 没有就是true
        if (mIsLoadDefaultRes) {
            return mAppResource.getDrawable(resId);
        }
        int skinId = getIdentifier(resId);
        if (skinId == 0) {
            return mAppResource.getDrawable(resId);
        }
        return mSkinResource.getDrawable(skinId);
    }

    /**
     * 可能是Color 也可能是drawable
     */
    public Object getBackground(int resId) {
        String resourceTypeName = mAppResource.getResourceTypeName(resId);

        if (resourceTypeName.equals("color")) {
            return getColor(resId);
        } else {
            // drawable
            return getDrawable(resId);
        }
    }

    public String getString(int resId) {
        try {
            if (mIsLoadDefaultRes) {
                return mAppResource.getString(resId);
            }
            int skinId = getIdentifier(resId);
            if (skinId == 0) {
                return mAppResource.getString(skinId);
            }
            return mSkinResource.getString(skinId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Typeface getTypeface(int resId) {
        String skinTypefacePath = getString(resId);
        if (TextUtils.isEmpty(skinTypefacePath)) {
            return Typeface.DEFAULT;
        }
        try {
            Typeface typeface;
            if (mIsLoadDefaultRes) {
                typeface = Typeface.createFromAsset(mAppResource.getAssets(), skinTypefacePath);
                return typeface;

            }
            typeface = Typeface.createFromAsset(mSkinResource.getAssets(), skinTypefacePath);
            return typeface;
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        return Typeface.DEFAULT;
    }
}
