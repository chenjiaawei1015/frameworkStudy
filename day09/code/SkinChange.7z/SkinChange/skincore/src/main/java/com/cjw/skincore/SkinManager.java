package com.cjw.skincore;

import android.app.Application;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.text.TextUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Observable;

public class SkinManager extends Observable {

    private static SkinManager sSkinManager;

    private Application mApplication;

    private SkinManager(Application application) {
        mApplication = application;

        registerActivityLifecycleCallbacks();

        SkinPreference skinPreference = SkinPreference.getInstance(application);
        String skinResourcePath = skinPreference.getSkinResourcePath();
        loadSkin(skinResourcePath);
    }

    private static SkinManager getInstance(Application application) {
        if (sSkinManager == null) {
            synchronized (SkinManager.class) {
                if (sSkinManager == null) {
                    sSkinManager = new SkinManager(application);
                }
            }
        }
        return sSkinManager;
    }

    public static SkinManager getInstance() {
        return sSkinManager;
    }

    /**
     * 初始化
     */
    public static void init(Application application) {
        sSkinManager = SkinManager.getInstance(application);
    }

    /**
     * 设置 Activity 生命周期回调
     */
    private void registerActivityLifecycleCallbacks() {
        SkinLifecycleCallback lifecycleCallback = new SkinLifecycleCallback();
        mApplication.registerActivityLifecycleCallbacks(lifecycleCallback);
    }

    /**
     * 加载插件包
     */
    public void loadSkin(String path) {
        SkinResource skinResource = SkinResource.getInstance(mApplication.getApplicationContext());
        SkinPreference skinPreference = SkinPreference.getInstance(mApplication);

        if (TextUtils.isEmpty(path)) {
            skinResource.reset();
            // 缓存当前的皮肤路径
            skinResource.reset();
            skinPreference.setSkinResourcePath("");

        } else {
            Resources resources = mApplication.getResources();

            try {
                Constructor<AssetManager> constructor = AssetManager.class.getConstructor();
                constructor.setAccessible(true);
                AssetManager assetManager = constructor.newInstance();

                Method addAssetPathMethod = assetManager.getClass().getDeclaredMethod(
                        "addAssetPath", String.class);
                addAssetPathMethod.setAccessible(true);
                addAssetPathMethod.invoke(assetManager, path);

                Resources skinRes = new Resources(assetManager, resources.getDisplayMetrics(),
                        resources.getConfiguration());

                //获取外部Apk(皮肤包) 包名
                PackageManager packageManager = mApplication.getPackageManager();
                PackageInfo info = packageManager.getPackageArchiveInfo(
                        path, PackageManager.GET_ACTIVITIES);
                String packageName = info.packageName;

                // 初始化皮肤 Resource
                skinResource.applySkin(skinRes, packageName);

                // 缓存当前的皮肤路径
                skinPreference.setSkinResourcePath(path);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        setChanged();
        // 通知观察者进行皮肤更换
        // 回调方法 SkinFactory2 中的 update 方法
        notifyObservers();
    }
}
