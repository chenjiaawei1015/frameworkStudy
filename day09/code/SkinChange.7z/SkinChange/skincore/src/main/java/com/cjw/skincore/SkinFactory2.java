package com.cjw.skincore;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;


public class SkinFactory2 implements LayoutInflater.Factory2, Observer {

    private static final String PREFIX_SYSTEM = "android.";

    private static final String[] PREFIX_NAME_ARR = {
            "android.widget.",
            "android.view.",
            "android.webkit.",
            "android.support.v7.widget."
    };

    private static final Class<?>[] mConstructorSignature =
            new Class[]{Context.class, AttributeSet.class};

    private static final HashMap<String, Constructor> sConstructorMap = new HashMap<>();

    private SkinAttribute mSkinAttribute = new SkinAttribute();

    private Context mContext;

    public SkinFactory2(Context context) {
        mContext = context;
    }

    @Override
    public View onCreateView(View parent, String name, Context context, AttributeSet attrs) {
        // 创建 View 对象

        View view;
        if (name.contains(".") && !name.startsWith(PREFIX_SYSTEM)) {
            // TODO: 2018/3/17 自定义控件
            return null;
        } else {
            view = createView(context, name, attrs);
        }

        if (view != null) {
            mSkinAttribute.load(view, attrs);
        }
        return view;
    }

    /**
     * 系统控件创建 View
     */
    private View createView(Context context, String name, AttributeSet attrs) {
        Constructor constructor = sConstructorMap.get(name);

        if (constructor == null) {
            String viewClazzName;

            if (name.startsWith(PREFIX_SYSTEM)) {
                viewClazzName = name;
                constructor = getConstructor(context, viewClazzName);

            } else {
                for (String prefix : PREFIX_NAME_ARR) {
                    viewClazzName = prefix + name;
                    constructor = getConstructor(context, viewClazzName);
                    if (constructor != null) {
                        break;
                    }
                }
            }
        }

        if (constructor != null) {
            try {
                sConstructorMap.put(name, constructor);
                return (View) constructor.newInstance(context, attrs);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * 根据类的全名称获取构造函数
     */
    private Constructor getConstructor(Context context, String viewClazzName) {
        ClassLoader loader = context.getClassLoader();
        Class<? extends View> viewClazz = null;
        try {
            viewClazz = loader.loadClass(viewClazzName).asSubclass(View.class);
        } catch (Exception ignored) {
        }

        if (viewClazz != null) {
            try {
                Constructor constructor = viewClazz.getConstructor(mConstructorSignature);
                constructor.setAccessible(true);
                return constructor;
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public View onCreateView(String name, Context context, AttributeSet attrs) {
        return onCreateView(null, name, context, attrs);
    }

    @Override
    public void update(Observable o, Object arg) {
        // 皮肤替换
        mSkinAttribute.updateSkin(mContext);
    }
}
