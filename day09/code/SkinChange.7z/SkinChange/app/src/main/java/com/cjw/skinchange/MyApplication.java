package com.cjw.skinchange;

import android.app.Application;

import com.cjw.skincore.SkinManager;


public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        SkinManager.init(this);
    }
}
