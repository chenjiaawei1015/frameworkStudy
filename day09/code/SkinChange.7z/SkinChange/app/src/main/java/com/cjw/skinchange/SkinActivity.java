package com.cjw.skinchange;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.view.View;

import com.cjw.skincore.SkinManager;

import java.io.File;

public class SkinActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skin);
    }

    public void change(View view) {
        // 换肤
        File file = new File(Environment.getExternalStorageDirectory(), "app-skin-debug.apk");
        // SkinManager.getInstance().loadSkin("/sdcard/app-skin-debug.skin");
        SkinManager.getInstance().loadSkin(file.getAbsolutePath());
    }

    public void restore(View view) {
        SkinManager.getInstance().loadSkin(null);
    }
}
