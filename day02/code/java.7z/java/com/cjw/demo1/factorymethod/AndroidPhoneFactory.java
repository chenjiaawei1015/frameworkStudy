package com.cjw.demo1.factorymethod;

/**
 * Created by Administrator on 2018/3/1.
 */

public class AndroidPhoneFactory implements IFactory {

    @Override
    public IProduct createPhone() {
        return new AndroidPhone();
    }
}
