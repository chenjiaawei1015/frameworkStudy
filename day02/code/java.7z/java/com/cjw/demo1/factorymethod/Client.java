package com.cjw.demo1.factorymethod;

import org.junit.Test;

/**
 * Created by Administrator on 2018/3/1.
 */

public class Client {

    @Test
    public void testProduct() {
        IFactory factory = new AndroidPhoneFactory();
        factory.createPhone().showName();
    }

}
