package com.cjw.demo1.factorymethod;

/**
 * Created by Administrator on 2018/3/1.
 */

public class AndroidPhone implements IProduct {

    @Override
    public void showName() {
        System.out.println("Android");
    }
}
