package com.cjw.demo1.factorymethod;

/**
 * Created by Administrator on 2018/3/1.
 */

public interface IProduct {

    void showName();

}
