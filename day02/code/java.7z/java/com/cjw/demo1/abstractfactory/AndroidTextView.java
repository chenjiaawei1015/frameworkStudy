package com.cjw.demo1.abstractfactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public class AndroidTextView implements ITextView {
    @Override
    public void showTextViewName() {
        System.out.println("Android TextView");
    }
}
