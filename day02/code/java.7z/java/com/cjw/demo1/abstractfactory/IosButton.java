package com.cjw.demo1.abstractfactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public class IosButton implements IButton {

    @Override
    public void showButtonName() {
        System.out.println("IOS Button");
    }
}
