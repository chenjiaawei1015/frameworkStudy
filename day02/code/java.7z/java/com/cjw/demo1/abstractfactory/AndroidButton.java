package com.cjw.demo1.abstractfactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public class AndroidButton implements IButton {

    @Override
    public void showButtonName() {
        System.out.println("Android Button");
    }
}
