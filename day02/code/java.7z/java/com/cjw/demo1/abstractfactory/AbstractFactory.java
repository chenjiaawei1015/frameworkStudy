package com.cjw.demo1.abstractfactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public abstract class AbstractFactory {

    public abstract IButton createButton();

    public abstract ITextView createTextView();

    public void showViewName() {
        IButton button = createButton();
        button.showButtonName();

        ITextView textView = createTextView();
        textView.showTextViewName();
    }

}
