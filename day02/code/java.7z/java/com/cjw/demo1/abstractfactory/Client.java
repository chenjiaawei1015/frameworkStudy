package com.cjw.demo1.abstractfactory;


import org.junit.Test;

/**
 * Created by Administrator on 2018/3/1.
 */

public class Client {

    @Test
    public void testProduct() {
        AbstractFactory factory = new AndroidFactory();
        factory.showViewName();

        factory = new IosFactory();
        factory.showViewName();
    }

}
