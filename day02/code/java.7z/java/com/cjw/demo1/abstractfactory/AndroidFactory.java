package com.cjw.demo1.abstractfactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public class AndroidFactory extends AbstractFactory {
    @Override
    public IButton createButton() {
        return new AndroidButton();
    }

    @Override
    public ITextView createTextView() {
        return new AndroidTextView();
    }
}
