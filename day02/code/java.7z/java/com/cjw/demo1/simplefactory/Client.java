package com.cjw.demo1.simplefactory;

import org.junit.Test;

/**
 * Created by Administrator on 2018/3/1.
 */

public class Client {

    @Test
    public void testProduct() {
        IProduct phone = Factory.createPhone(Factory.TYPE_ANDROID);
        phone.showName();

        IProduct product = Factory.createProduct(IosPhone.class);
        if (product != null) {
            product.showName();
        }
    }
}
