package com.cjw.demo1.simplefactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public class Factory {

    public static final int TYPE_ANDROID = 1;
    public static final int TYPE_IOS = 2;

    public static IProduct createPhone(int type) {
        switch (type) {
            case TYPE_ANDROID:
                return new AndroidPhone();
            case TYPE_IOS:
                return new IosPhone();
            default:
                return new IosPhone();
        }
    }

    public static <T extends IProduct> IProduct createProduct(Class<T> tClass) {
        try {
            return (IProduct) Class.forName(tClass.getName()).newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
