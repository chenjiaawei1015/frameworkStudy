package com.cjw.demo1.simplefactory;

/**
 * Created by Administrator on 2018/3/1.
 */

public class IosPhone implements IProduct {

    @Override
    public void showName() {
        System.out.println("IOS");
    }
}
